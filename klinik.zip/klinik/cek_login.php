<?php
if(isset($_POST['login'])){
	session_start(); 		//mulai session, krena kita akan menggunakan session pd file php ini
	include 'koneksi.php'; 		//hubungkan dengan config.php untuk berhubungan dengan database
	$username=$_POST['user']; 	//tangkap data yg di input dari form login input username
	$password=$_POST['pass']; 	//tangkap data yg di input dari form login input password
	
	$query=mysql_query("select * from karyawan where id_karyawan='$username' and password='$password'");//melakukan pengampilan data dari database untuk di cocokkan
	$xxx=mysql_num_rows($query);	 //melakukan pencocokan
	if($xxx > 0){ 	
		$data = mysql_fetch_array($query);	
		$_SESSION['user']=$username;
		$_SESSION['pass']=$password;
		$_SESSION['level']=$data['user'];
		$_SESSION['nama']=$data['nama_karyawan'];
		if($data['user'] == 'perawat')
			{
				header("location:perawat/home.php");
			}
		elseif ($data['user'] == 'dokter')
			{
				header("location:dokter/home.php");
			}
			else
		//elseif ($data['user'] == 'apoteker')
			{
				header("location:apoteker/home.php");
			}    
	}else{   
		echo "<script>alert('GAGAL LOGIN!! Username atau Password Anda tidak benar.')</script>
				<script>window.history.back()</script>";
	}
}
?>