<?php  
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='dokter'){
?>
<html>
<title>TULIS DIAGNOSA</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
  <div id="wrapper">
    <div id="header">
      <div class="logo">
        <center><img src="1.png" width="100px" height="100px" /></center>
      </div>
      <div class="banner">
      <font size="6">KLINIK SYAHRIAL MEDICA</font><br />
      <font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
        <strong>Phone:</strong>0813-7214-0750
      </div>
    </div>
  <div id="menu">
    <a href="tampildatapendaftar.php">DIAGNOSA</a>
    <a href="tampildataresep.php">RESEP</a>
    <a href="tampildataobat.php">CARI OBAT</a>
    <a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
  </div>
  <div id="content">
    <div class="left-menu">
      <b><u>DIAGNOSA</u></b>
      <ul class="external-link">
        <li><a href="tampildatapendaftar.php">Tampil Data Karyawan</a></li>
      </ul>
    </div>
  <div class="page">
    <h1>INPUT DIAGNOSA DAN HASIL KONSULTASI</h1>
<?php
  include "koneksi.php";
    $idp = $_GET['idp'];
    $idk = $_GET['idk'];
    $idr = $_GET['idr'];
  $show = mysql_query("select karyawan.id_karyawan, pasien.no_medicalrecord, karyawan.spesialis, karyawan.nama_karyawan, pasien.nama, pasien.gender, memeriksa.id_resep from karyawan, pasien, memeriksa where karyawan.id_karyawan = memeriksa.id_karyawan and pasien.no_medicalrecord = memeriksa.no_medicalrecord and memeriksa.id_karyawan= '$idk' and memeriksa.no_medicalrecord= '$idp' and memeriksa.id_resep = '$idr'");
  if(mysql_num_rows($show) == 0)
    {   
    }
    else {
        $ed = mysql_fetch_assoc($show);   
    }
?>  
<form method="post" action="fungsiadddiagnosa.php">
<input type="hidden" name="no_medicalrecord" value="<?php echo $ed['no_medicalrecord']?>">
<input type="hidden" name="id_karyawan" value="<?php echo $ed['id_karyawan']?>">
<input type="hidden" name="id_resep" value="<?php echo $ed['id_resep']?>">
<table width="100%" height="50" border="0" cellpadding="5" cellspacing="0">  
  <tbody>
  <tr>
    <td>Tanggal</td>  
    <td>: <input type="datetime" name="tanggal" size="50" value="<?php
            $tanggal= mktime(date("m"),date("d"),date("Y"));
            echo date("Y/m/d", $tanggal)." ";
            date_default_timezone_set('Asia/Jakarta');
            $jam=date("H:i:s");
            echo $jam;
            ?>" readonly="readonly" required></td>  
  </tr>
  <tr>
    <td>Nama Dokter</td>  
    <td>: <input type="text" name="namakaryawan" size="50" readonly="readonly" value="<?php echo $ed['nama_karyawan']; ?>" required></td>  
  </tr>
    <td>Nama Poli </td>  
    <td>:<?php
        if($ed['spesialis'] == "Umum"){
        echo"<input type='radio' name='spesialis' value='Umum' size='25' checked> Umum
        <input type='radio' name='spesialis' value='Gigi' size='25' disabled> Gigi";
        }else{
        echo"<input type='radio' name='spesialis' value='Umum' size='25' disabled> Umum
        <input type='radio' name='spesialis' value='Gigi' size='25' checked> Gigi";
        } ?>

    </td>  
  </tr>  
    <tr>
      <td>Nama Pasien</td>
      <td>:
      <input type="text" name="namapasien" size="50" readonly="readonly" value="<?php echo $ed['nama']; ?>" required>
      <a href="lihatdiagnosalama.php?id=<?php echo $ed['no_medicalrecord'];?>" target="_blank">Diagnosa Lama</a></td>
    </tr>
    <td>Jenis Kelamin </td>  
    <td>:
      <?php  
        if($ed['gender'] == "laki-laki"){
        echo"<input type='radio' name='gender' value='laki-laki' size='25' checked> Laki-Laki
        <input type='radio' name='gender' value='perempuan' size='25'disabled> Perempuan";
        }else{
        echo"<input type='radio' name='gender' value='laki-laki' size='25' disabled> Laki-Laki
        <input type='radio' name='gender' value='perempuan' size='25' checked> Perempuan";
        } ?>
    </td>  
  </tr>
    <td><strong>Diagnosa </strong></td>
    <td>: </td> 
  </tr>
  <tr>
    <td height="45">Jenis Penyakit</td>  
    <td>:      
      <textarea name="jenis_penyakit" cols="50" rows="7" required></textarea></td>
  </tr>
  <tr>  
    <td>Jenis Pengobatan</td>  
    <td>: <textarea name="jenis_pengobatan" cols="50" rows="7" required></textarea></td>  
  </tr>
  <tr>  
    <td>Tindakan</td>  
    <td>: <textarea name="tindakan" cols="50" rows="7" placeholder="BILA DILAKUKAN TINDAKAN" ></textarea></td>  
  </tr>
  <tr>  
    <td>Biaya Tindakan</td>  
    <td>: Rp. <input type="text" name="biaya_tindakan" placeholder="BILA DILAKUKAN TINDAKAN" size="46" ></textarea></td>  
  </tr>
  <tr>  
    <td colspan="2"><input type="submit" name="submit" value="&radic; OK"> <input type="reset"></td>  
  </tr>  
  </tbody>    
</table>  
  </div>
</div>
<div id="footer">&copy; FNF 2016</div>
</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='dokter'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>