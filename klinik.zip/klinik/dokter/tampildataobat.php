<?php
include "koneksi.php";
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='dokter'){
?>
<html>
<title>DATA OBAT</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
  <div id="wrapper">
    <div id="header">
      <div class="logo">
        <center><img src="1.png" width="100px" height="100px" /></center>
      </div>
      <div class="banner">
      <font size="6">KLINIK SYAHRIAL MEDICA</font><br />
      <font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
        <strong>Phone:</strong>0813-7214-0750
      </div>
    </div>
  <div id="menu">
    <a href="tampildatapendaftar.php">DIAGNOSA</a>
    <a href="tampildataresep.php">RESEP</a>
    <a href="tampildataobat.php">CARI OBAT</a>
    <a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
  </div>
  <div id="content">
    <div class="left-menu">
      <b><u> OBAT </u></b>
      <ul class="external-link">
        <li><a href="tampildataobat.php">Tampil Data Obat</a></li>
        <li><a href="adddataobat.php">Tambah Data Obat</a></li>
      </ul>
    </div>
  <div class="page">
    <h1>Data Obat Klinik Syahrial Medica</h1>
<form method="post">
<table width="100%" border="0" cellspacing="0" cellpadding="5">
    <tbody>
      <tr>
        <td>
        Pencarian Obat Berdasarkan : 
        <select name="pilihobat">
          <option value="pilihan">Pilihan</option>
            <option value="nama">nama obat</option>
          <option value="kategori">kategori obat</option>
            
        </select> :
          <input type="text" name = "kode" placeholder="Pencarian" size="30" required>
        <input type="submit" name="search" value="search">
        </td>  
      </tr>
    </tbody>
  </table></form>
<?php 
if(isset($_POST['search'])){
include "cariobat.php";
}else{
echo("
    <table width='100%' border='0' cellspacing='0' cellpadding='5'>  
      <thead>  
      <th>No</th>  
        <th>id Obat</th>  
        <th>Nama</th>  
        <th>Harga</th>  
        <th>Jumlah</th>  
        <th>Kategory</th>
        <th>Perusahaan</th>
      </thead>  
      <tbody>  
      ");  
      $q = mysql_query("SELECT * FROM `obat` ORDER BY id_obat ASC");  
      $num = 1;

      while ($dat = mysql_fetch_array($q)){  
      echo("                    
      <tr>  
        <td align=center>".$num++."</td>  
        <td align=center>$dat[id_obat]</td>  
        <td align=center>$dat[nama]</td>  
        <td align=center>$dat[harga]</td>  
        <td align=center>$dat[jumlah]</td>  
        <td align=center>$dat[kategori]</td>
        <td align=center>$dat[perusahaan]</td>
      </tr>  
      ");  
      }  
      echo("   
      </tbody>  
    </table>              
"); }?>
  </div>
</div>
<div id="footer">&copy; FNF 2016</div>
</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='dokter'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>