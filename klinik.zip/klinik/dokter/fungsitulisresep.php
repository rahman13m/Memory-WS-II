<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='dokter'){
if(isset($_POST['Tambah']))
{
	include "koneksi.php";
    $id_obat = $_POST['id_obat'];
    $jumlah = $_POST['jumlah'];
    $id_resep = $_POST['id_resep']; 
    $namapasien = $_POST['namapasien'];
    $no_medicalrecord = $_POST['no_medicalrecord'];
    $angka = $_POST['angka'];
    $makan = $_POST['makan'];
    $dosis2 =$_POST['dosis2'];
    if($angka!=""&&$makan!=""&&$dosis2!=""){
        echo "<script> alert('Pilih Salah Satu Field Dosis!');window.location='tulisresep.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep';</script>";
    }if($angka==""&&$makan==""&&$dosis2==""){
        echo "<script> alert('Dosis Belum Diisi!');window.location='tulisresep.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep';</script>";
    }else{
        $arr_dosis = array("$angka", "$makan");
        $dosis = implode(" ", $arr_dosis);
        $id_karyawan = $_POST['id_karyawan'];
        $cek=mysql_query("select * from obat where id_obat = '$id_obat'");
        $data = mysql_fetch_array($cek);
        $namaobat = $data['nama'];
        $hargasatuan = $data['harga'];
        $jmlh = $data['jumlah'];
        $totalharga = $hargasatuan * $jumlah;
        $jmlhbaru = $jmlh - $jumlah;
        if($jumlah > $jmlh){
            echo "<script> alert('Stok Obat Tidak Cukup!');window.location='tulisresep.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep';</script>";
        }else{
            if($dosis!=''&&$dosis2==''){
                $add = mysql_query("INSERT INTO `db_klinik`.`mendapatkan` (`id_resep`, `no_medicalrecord`, `id_obat`, `namaobat`, `hargasatuan`, `dosis`, `jumlah`, `harga`) VALUES ('$id_resep', '$no_medicalrecord', '$id_obat', '$namaobat', '$hargasatuan', '$dosis', '$jumlah', '$totalharga')");
             }else{
                $add = mysql_query("INSERT INTO `db_klinik`.`mendapatkan` (`id_resep`, `no_medicalrecord`, `id_obat`, `namaobat`, `hargasatuan`, `dosis`, `jumlah`, `harga`) VALUES ('$id_resep', '$no_medicalrecord', '$id_obat', '$namaobat', '$hargasatuan', '$dosis2', '$jumlah', '$totalharga')");
            }
            $update = mysql_query("UPDATE `obat` SET `jumlah`= '$jmlhbaru' WHERE `id_obat` = '$id_obat'");
            if($add && $update){  
                echo("  
                    <script>alert('Data Resep [ $namapasien ] berhasil ditambahkan')</script>  
                    <meta http-equiv=refresh content='0; url=tulisresep.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep' >  
                ");  
            }else{  
                echo("  
                    <script>alert('ERROR | Data gagal di input')</script>  
                    <meta http-equiv=refresh content='0; url=tulisresep.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep' >  
                ");   
            }
        }
    }
}
}elseif(isset($user)&&$level!='dokter'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>