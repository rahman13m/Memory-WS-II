<?php  
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='dokter'){

if(isset($_GET['idr'])){	
include "koneksi.php"; 
$id_resep = $_GET['idr'];
$no_medicalrecord = $_GET['idp'];
$id_karyawan = $_GET['id_karyawan'];
$cek = mysql_query("SELECT * FROM mendapatkan WHERE no_medicalrecord='$no_medicalrecord' and id_resep = '$id_resep'") or die(mysql_error());
$bwah = mysql_fetch_array($cek);
$nama = $bwah['namaobat'];
$jumlah = $bwah['jumlah'];
$id_obat = $bwah['id_obat'];
$cek2 = mysql_query("SELECT * FROM obat where id_obat = '$id_obat'");
$bwah2 = mysql_fetch_array($cek2);
$jumlahobat = $bwah2['jumlahobat'];
$jmlhbaru = $jumlahobat+$jumlah;
if(mysql_num_rows($cek) == 0)
	{
		echo '<script>window.history.back()</script>';
	}	
else
	{
		$del = mysql_query("DELETE FROM `db_klinik`.`mendapatkan` WHERE `mendapatkan`.`no_medicalrecord` = '$no_medicalrecord' and `mendapatkan`.`id_resep` = '$id_resep'");
		$update = mysql_query("UPDATE `obat` SET `jumlah`= '$jmlhbaru' WHERE `id_obat` = '$id_obat'");
		if($del&&$update){  
		echo("  
			<script>alert('Data Resep [$nama] berhasil dihapus')</script>  
			<meta http-equiv=refresh content='0; url=tulisresep.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep' >  
        ");
		}
		else {  
        echo("  
            <script>alert('ERROR | Data gagal di input')</script>  
            <meta http-equiv=refresh content='0; url=tulisresep.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep' >  
        ");
		}
	}
}
}elseif(isset($user)&&$level!='dokter'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>