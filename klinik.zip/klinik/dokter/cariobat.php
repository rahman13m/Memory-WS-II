<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='dokter'){

	$kode=$_POST['kode'];
	$pilihobat=$_POST['pilihobat'];

	if ($pilihobat == 'nama') {
		$sql = "select * from obat where nama like '%$kode%'";
	} else if ($pilihobat == 'kategori') {
		$sql = "select * from obat where kategori like '%$kode%'";
	}
	$result = mysql_query($sql);
	if(mysql_num_rows($result) > 0){
		?>
		<table width='100%' border='0' cellspacing='0' cellpadding='5'>
		<thead> 
        	<th>ID Obat</th>  
        	<th>Nama</th>  
        	<th>Harga</th>  
        	<th>Jumlah</th>  
        	<th>Kategori</th>
		</thead>
			<?php
			while($tampil = mysql_fetch_array($result)){?>
			<tr>
				<td><?php echo $tampil['id_obat'];?></td>
				<td><?php echo $tampil['nama'];?></td>
				<td><?php echo $tampil['harga'];?></td>
				<td><?php echo $tampil['jumlah'];?></td>
				<td><?php echo $tampil['kategori'];?></td>
			</tr>
			<?php }?>
		</table>
		<?php
	}else{
		echo 'Data not found!'; 
	}
}elseif(isset($user)&&$level!='dokter'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>