<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='dokter'){

if(isset($_POST['submit']))
{
	include "koneksi.php";
    $namadokter = $_POST['namakaryawan'];
    $nama_poli = $_POST['spesialis'];
    $id_karyawan = $_POST['id_karyawan'];
    $no_medicalrecord = $_POST['no_medicalrecord'];
    $tanggal = $_POST['tanggal'];
    $namapasien = $_POST['namapasien']; 
    $gender = $_POST['gender'];  
    $jenis_penyakit= $_POST['jenis_penyakit'];
	$jenis_pengobatan = $_POST['jenis_pengobatan'];
	$tindakan = $_POST['tindakan'];
	$biaya_tindakan = $_POST['biaya_tindakan'];
    $id_resep = $_POST['id_resep'];
    if(($biaya_tindakan==''&&$tindakan!='')||($biaya_tindakan!=""&&$tindakan=='')){
        echo "<script> alert('Data Belum Lengkap!');window.location='adddiagnosa.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep';</script>";
    }else{
    	$link = mysql_connect('localhost', 'root', '');
        $db_selected = mysql_select_db('db_klinik');
        $add = mysql_query("UPDATE `db_klinik`.`memeriksa` SET `nama_poli` = '$nama_poli', `tanggal` = '$tanggal', `tindakan` = '$tindakan', `jenis_penyakit` = '$jenis_penyakit', `jenis_pengobatan` = '$jenis_pengobatan', `biaya_tindakan` = '$biaya_tindakan', `status_pembayaran` = 'belum dibayar', `status_diagnosa` = 'sudah dicek' WHERE `memeriksa`.`id_resep` = '$id_resep'");  
        if($add){  
            echo("  
                <script>alert('Data Diagnosa [ $namapasien ] berhasil ditambahkan')</script>  
                <meta http-equiv=refresh content='0; url=tulisresep.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep' >  
            ");  
        }
        else{  
            echo("  
                <script>alert('ERROR | Data gagal di input')</script>  
                <meta http-equiv=refresh content='0; url=adddiagnosa.php?idk=$id_karyawan&idp=$no_medicalrecord' >  
            ");   
        }
    }
}
}elseif(isset($user)&&$level!='dokter'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>