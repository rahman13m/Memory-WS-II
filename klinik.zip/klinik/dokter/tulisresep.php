<?php  
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='dokter'){
?>
<html>
<title>TULIS RESEP</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
	<div id="wrapper">
		<div id="header">
			<div class="logo">
				<center><img src="1.png" width="100px" height="100px" /></center>
			</div>
			<div class="banner">
			<font size="6">KLINIK SYAHRIAL MEDICA</font><br />
			<font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
				<strong>Phone:</strong>0813-7214-0750
			</div>
		</div>
	<div id="menu">
		<a href="tampildatapendaftar.php">DIAGNOSA</a>
		<a href="tampildataresep.php">RESEP</a>
		<a href="tampildataobat.php">CARI OBAT</a>
		<a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
	</div>
	<div id="content">
		<div class="left-menu">
			<b><u>RESEP</u></b>
      		<ul class="external-link">
        		<li><a href="tampildatapendaftar.php">Tampil Data Pendaftar</a></li>
      		</ul>
		</div>
	<div class="page">
		<?php
  include "koneksi.php";
    $idp = $_GET['idp'];
    $idk = $_GET['idk'];
    $idr = $_GET['idr'];
  $show = mysql_query("select karyawan.id_karyawan, pasien.no_medicalrecord, karyawan.spesialis, karyawan.nama_karyawan, pasien.nama, pasien.gender, memeriksa.jenis_penyakit, memeriksa.id_resep, memeriksa.keterangan_resep from karyawan, pasien, memeriksa where karyawan.id_karyawan = memeriksa.id_karyawan and pasien.no_medicalrecord = memeriksa.no_medicalrecord and memeriksa.no_medicalrecord='$idp' and memeriksa.id_resep = '$idr'");
  if(mysql_num_rows($show) == 0)
    {   
    }
    else {
        $ed = mysql_fetch_assoc($show);   
    }
?>
<form method="post" action="fungsitulisresep.php">
<input type="hidden" name="no_medicalrecord" value="<?php echo $ed['no_medicalrecord']?>">
<input type="hidden" name="id_karyawan" value="<?php echo $ed['id_karyawan']?>">
<input type="hidden" name="id_resep" value="<?php echo $ed['id_resep']?>">
	<table width="100%" border="0" cellspacing="0" cellpadding="5">
		<tbody>
			<tr>
      			<td>Nama Pasien</td>
      			<td>: <input type="text" name="namapasien" size="50" readonly="readonly" value="<?php echo $ed['nama']; ?>" required>
      			<a href="lihatdiagnosalama.php?id=<?php echo $ed['no_medicalrecord'];?>" target="_blank">Diagnosa Lama</a></td>
      			</td>
    		</tr>
			<tr>
				<td>Gender</td>
				<td>:
      				<?php  
        			if($ed['gender'] == "laki-laki"){
 			       	echo"<input type='radio' name='gender' value='laki-laki' size='25' checked> Laki-Laki
 			       	<input type='radio' name='gender' value='perempuan' size='25'disabled> Perempuan";
  			      	}else{
   			     	echo"<input type='radio' name='gender' value='laki-laki' size='25' disabled> Laki-Laki
    			    <input type='radio' name='gender' value='perempuan' size='25' checked> Perempuan";
        			} ?>
    			</td>
			</tr>
			<tr>
				<td> Di Diagnosa Oleh </td>
				<td> : <input type="text" name="namakaryawan" size="50" readonly="readonly" value="<?php echo $ed['nama_karyawan']; ?>" required></td>
			</tr>
			<tr>
				<td height="45">Hasil Diagnosa</td>  
    			<td> :      
      				<textarea name="jenis_penyakit" cols="54" rows="7" readonly="readonly" required><?php echo $ed['jenis_penyakit']; ?></textarea></td>
			</tr>
			<tr>
				<td><strong>PEMBUATAN RESEP</strong></td>
				<td> : </td>
			</tr>
			<tr>
				<td>ID Resep</td>
        		<td>: <input type="text" name="id_resep" placeholder="ID Resep" value="<?php echo $ed['id_resep']?>" readonly="readonly" size="25"></td>
        		<?php $id_resep = $ed['id_resep']; ?>
			</tr>
		</tbody>
	</table>
	<table width="100%" border="0" cellspacing="0" cellpadding="5">
		<tr>
			<td width="225"><strong> INPUT OBAT: </strong></td>
			<td></td>
		</tr>
		<tr>
			<td width="225">ID Obat</td>
			<td> : 
				<select name="id_obat">
      			 <option value=''>Pilih Obat</option>
      			  <?php
      				if($q=mysql_query("select id_obat, nama from obat order by id_obat asc")){
          				if (mysql_num_rows($q) > 0) {
          			 	while ($dtq=mysql_fetch_array($q)) {
         				    echo "<option value='".$dtq['id_obat']."'>".$dtq['nama']." (".$dtq['id_obat'].")</option>";
          			 	 }
         				}else{
          			 		echo "<option value=''>Data Obat Kosong</option>";
         				}
        			}
         		?>
			</select></td>
		</tr>
		<tr>
			<td width="235">Dosis Obat</td>
			<td> : <select name="angka">
				<option value="">--</option>
				<?php 
					for ($i=1; $i <= 10 ; $i++) { 
						echo ("<option value='$i Kali'>$i</option>");
					}
					
				?>
				</select> &nbsp; Kali Sehari &nbsp;
				<input type="radio" name="makan" value="Sesudah Makan"> Sesudah Makan
				<input type="radio" name="makan" value="Sebelum Makan"> Sebelum Makan <br>
				<input type="text" name="dosis2" placeholder="DOSIS DIISI DILUAR PILIHAN" size="50">
			</td>
		</tr>
		<tr>
			<td width="235">Jumlah Obat</td>
			<td> : <input type="text" name="jumlah" placeholder="JUMLAH OBAT" size='10' required></td>
		</tr>
		<tr>
			<td><input name="Tambah" type="submit" id="Tambah" value="Tambah" /></td>
			<td></td>
		</tr>
	</table>
	</form>
	<form method="post" action="tambahketeranganresep.php">
	<input type="hidden" name="no_medicalrecord" value="<?php echo $ed['no_medicalrecord']?>">
	<input type="hidden" name="id_karyawan" value="<?php echo $ed['id_karyawan']?>">
	<input type="hidden" name="id_resep" value="<?php echo $ed['id_resep']?>">
	<input type="hidden" name="nama" value="<?php echo $ed['nama']?>">
		<table width="100%" border="0" cellspacing="0" cellpadding="5">
			<tr>
				<td><strong>TAMBAHAN RESEP</strong></td><td></td>
			</tr>
			<tr>
				<td>Keterangan Resep </td>
				<td> : <textarea name="keterangan_resep" cols="50" rows="3" placeholder="BILA ADA OBAT DILUAR APOTEK"></textarea></td>
			</tr>
			<tr>
				<td><input type="submit" value="Simpan" name="Simpan"></td><td></td>
			</tr>
		</table>
	</form>
	<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<thead>
		<tr>
			<th style="text-align:center">No</th>
			<th style="text-align:center">ID Obat</th>
			<th style="text-align:center">Nama Obat</th>
			<th style="text-align:center">Harga Satuan</th>
			<th style="text-align:center">Jumlah Beli</th>
			<th style="text-align:center">Dosis</th>
			<th style="text-align:center">Total</th>
			<th style="text-align:center">Aksi</th>
		</tr>
		</thead>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<tbody>
<?php
include 'koneksi.php';
$sql = "select * from mendapatkan where id_resep = '$id_resep'";
$query = mysql_query($sql);
$no =0;
$total =0;
while($data = mysql_fetch_array($query))
{
	$subtotal=$data['harga'];
	$total = $total + $subtotal;
	$no++;
	echo "
	<td><center>".$no."</center></td>
	<td><center>".$data['id_obat']."</center></td>
	<td><center>".$data['namaobat']."</center></td>
	<td><center>".$data['hargasatuan']."</center></td>
	<td><center>".$data['jumlah']."</center></td>
	<td><center>".$data['dosis']."</center></td>
	<td><center>".$data['harga']."</center></td>
	<td><center><a href=hapusresep.php?idr=$data[id_resep]&idp=$data[no_medicalrecord]><button>HAPUS</button></a></center></td>
	</tr>";
}	
	echo "<th></th>";
	echo "<th></th>";
	echo "<th></th>";
	echo "<th></th>";
	echo "<th></th>";
	echo "<th></th>";
	echo "<th style='text-align:center'>".$total."</th>";
	echo "<th></th>";
	echo '</table>';
?>
</tbody>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
		<td width="235"><strong>Keterangan Resep</strong></td><td> : <?php echo $ed['keterangan_resep']; ?></td>
	</tr>
</table>
	</div>
</div>
<div id="footer">&copy; FNF 2016</div>
</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='dokter'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>