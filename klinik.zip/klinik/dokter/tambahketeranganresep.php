<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='dokter'){
	if(isset($_POST['Simpan']))
	{
		include "koneksi.php";
	    $id_resep = $_POST['id_resep'];
	    $keterangan_resep = $_POST['keterangan_resep'];
	    $no_medicalrecord = $_POST['no_medicalrecord'];
	    $id_karyawan = $_POST['id_karyawan'];
	    $namapasien = $_POST['nama'];
	    $sql= mysql_query("select * from memeriksa where id_resep = '$id_resep'");
	    $a=mysql_fetch_array($sql);
	    $keterangan_reseplm = $a['keterangan_resep'];

	    $tmbhketerangan = mysql_query("UPDATE `db_klinik`.`memeriksa` SET `keterangan_resep` = '$keterangan_reseplm, $keterangan_resep' WHERE `id_resep` = '$id_resep'");
	    if($tmbhketerangan){
	    	 echo("  
                <script>alert('Keterangan Resep [ $namapasien ] berhasil ditambahkan')</script>  
                <meta http-equiv=refresh content='0; url=tulisresep.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep' >  
            "); 
	    }else{
	    	echo("  
                <script>alert('ERROR | Data gagal di input')</script>  
                <meta http-equiv=refresh content='0; url=tulisresep.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep' >  
            "); 
	    }
	}
}elseif(isset($user)&&$level!='dokter'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>