<?php  
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){
?>
<html>
<title>DIAGNOSA SEBELUMNYA</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
	<div id="wrapper">
		<div id="header">
			<div class="logo">
				<center><img src="1.png" width="100px" height="100px" /></center>
			</div>
			<div class="banner">
			<font size="6">KLINIK SYAHRIAL MEDICA</font><br />
			<font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
				<strong>Phone:</strong>0813-7214-0750
			</div>
		</div>
	<div id="menu">
		<a href="tampildatapasien.php">PASIEN</a>
		<a href="tampildatakaryawan.php">KARYAWAN</a>
		<a href="tampildatapendaftar.php">PENDAFTARAN</a>
		<a href="tampildatapembayar.php">PEMBAYARAN</a>
    	<a href="penghasilan.php">PENGHASILAN</a>
		<a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
	</div>
	<div id="content">
		<div class="left-menu">
			<b><u>DIAGNOSA SEBELUMNYA</u></b>
			<ul class="external-link">
        		<li><a href="tampildatapasien.php">Tampil Data Pasien</a></li>
        		<li><a href="addpasien.php">Tambah Data Pasien</a></li>
      			</ul>
		</div>
	<div class="page">
		<h1>Lihat Rekap Diagnosa Sebelumnya</h1>
<?php
  include "koneksi.php";
    $no_medicalrecord = $_GET['id'];
	$show = mysql_query("SELECT * FROM pasien WHERE no_medicalrecord='$no_medicalrecord'");
	if(mysql_num_rows($show) == 0)
		{   
		}
		else {
		    $ed = mysql_fetch_assoc($show);   
		}
?>  
<form method="post" action="fungsieditpasien.php">
<table width="100%" border="0" cellspacing="0" cellpadding="5">  
  <tbody>
  <tr>
				<td>No Medical Record</td>
				<td>: <input type="text" name="no_medicalrecord" placeholder="No Medica Record" size="23" readonly="readonly" value="<?php echo $ed['no_medicalrecord']; ?>" readonly="readonly"> &nbsp; No.Rak : <input type="text" name="no_rak" placeholder="No.Rak" size="9" value="<?php echo $ed['no_rak']; ?>" readonly="readonly"> </td>
			</tr>
			<tr>
				<td>Nama Pasien</td>
				<td>: <input type="text" name="nama" placeholder="Nama Pasien" size="50" value="<?php echo $ed['nama']; ?>" readonly="readonly"> </td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td>: <input type="text" name="alamat" placeholder="Alamat Pasien" size="50"  value="<?php echo $ed['alamat']; ?>" readonly="readonly"> </td>
			</tr>
			<tr>
				<td>Nomor Telepon</td>
				<td>: <input type="text" name="no_telp" placeholder="Nomor Telepon Pasien" size="50" value="<?php echo $ed['no_telp']; ?>" readonly="readonly"></td>
			</tr>
			<tr>
				<td>Tanggal Lahir</td>
				<td>: <input type="date" name="tanggal_lahir" placeholder="Tanggal Lahir Pasien" size="50" value="<?php echo $ed['tanggal_lahir']; ?>" readonly="readonly"> </td>
			</tr>
			<tr>
				<td>Jenis Kelamin</td>
				<td>:
				<?php  
				if($ed['gender'] == "laki-laki"){
				echo"<input type='radio' name='gender' value='laki-laki' size='25' checked> Laki-Laki
				<input type='radio' name='gender' value='perempuan' size='25' disabled> Perempuan";
				}else{
				echo"<input type='radio' name='gender' value='laki-laki' size='25' disabled> Laki-Laki
				<input type='radio' name='gender' value='perempuan' size='25' checked> Perempuan";
				} ?>
				</td>
			</tr>
  </tbody>    
</table>  
</form>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<thead>
		<tr>
			<th style="text-align:center">No</th>
			<th style="text-align:center">Tanggal</th>
			<th style="text-align:center">Nama Dokter</th>
			<th style="text-align:center">Nama Poli</th>
			<th style="text-align:center">Diagnosa</th>
			<th style="text-align:center">Pengobatan</th>
			<th style="text-align:center">Tindakan</th>
		</tr>
		</thead>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<?php
include 'koneksi.php';
$sql = "select memeriksa.nama_poli, DAYOFMONTH(memeriksa.tanggal) as hari, MONTHNAME(memeriksa.tanggal) as bulan, YEAR(memeriksa.tanggal) as tahun, karyawan.nama_karyawan, memeriksa.jenis_penyakit, memeriksa.jenis_pengobatan, memeriksa.tindakan from memeriksa, karyawan where no_medicalrecord = '$no_medicalrecord' and memeriksa.id_karyawan = karyawan.id_karyawan and memeriksa.status_pembayaran = 'sudah dibayar'";
$query = mysql_query($sql);
$no =0;
$total =0;
while($data = mysql_fetch_array($query))
{
	$no++;
	echo "
	<td><center>".$no."</center></td>
	<td><center>".$data['hari']." ".$data['bulan']." ".$data['tahun']."</center></td>
	<td><center>".$data['nama_karyawan']."</center></td>
	<td><center>".$data['nama_poli']."</center></td>
	<td><center>".$data['jenis_penyakit']."</center></td>
	<td><center>".$data['jenis_pengobatan']."</center></td>
	<td><center>".$data['tindakan']."</center></td>
	</tr>";
}
echo '</table>'; 
?>
</tbody>
</table>
	</div>
</div>
<div id="footer">&copy; FNF 2016</div>
</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>