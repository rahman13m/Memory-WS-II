<?php
include "koneksi.php";
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){
?>
<html>
<title>PENGHASILAN</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
    <div id="wrapper">
        <div id="header">
            <div class="logo">
                <center><img src="1.png" width="100px" height="100px" /></center>
            </div>
            <div class="banner">
            <font size="6">KLINIK SYAHRIAL MEDICA</font><br />
            <font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
                <strong>Phone:</strong>0813-7214-0750
            </div>
        </div>
    <div id="menu">
        <a href="tampildatapasien.php">PASIEN</a>
        <a href="tampildatakaryawan.php">KARYAWAN</a>
        <a href="tampildatapendaftar.php">PENDAFTARAN</a>
        <a href="tampildatapembayar.php">PEMBAYARAN</a>
        <a href="penghasilan.php">PENGHASILAN</a>
        <a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
    </div>
    <div id="content">
        <div class="left-menu">
            <b><u>PENGHASILAN</u></b>
            <ul class="external-link">
                <li><a href="penghasilan.php">Cek Penghasilan</a></li>
            </ul>
        </div>
    <div class="page">
  <?php
  if (isset($_POST['submit'])) {
	include 'koneksi.php';
	$awal = $_POST['awal'];
    $akhir = $_POST['akhir'];
    #bikin jadi tanggal+1
    $arr_akhir = explode("-", $akhir);
    $tanggalbaru = $arr_akhir[2] + 1;
     if($tanggalbaru>31) {
      $tanggalbaru=+1;
      $arr_akhir[1]=$arr_akhir[1]+1;
    }if ($arr_akhir[1]>12) {
      $arr_akhir[1]=1;
      $arr_akhir[0]=$arr_akhir[0]+1;
    }
    $arr_akhirbaru = array("$arr_akhir[0]", "$arr_akhir[1]", "$tanggalbaru");
    $akhirbaru = implode("-", $arr_akhirbaru);

    $total_tk=0;
    $total_bt=0;
    $total_resep=0;
    $cek = mysql_query("select karyawan.id_karyawan, karyawan.tarif_konsultasi, memeriksa.biaya_tindakan, memeriksa.total_harga, memeriksa.id_resep from karyawan, memeriksa where karyawan.id_karyawan = memeriksa.id_karyawan and memeriksa.status_pembayaran = 'sudah dibayar' and memeriksa.tanggal >= '$awal' and memeriksa.tanggal <= '$akhirbaru'");
    if (mysql_num_rows($cek) > 0) {
        while($tampil = mysql_fetch_array($cek)){
            $jumlahpasien = mysql_num_rows($cek);
            $jumlahresep = mysql_num_rows($cek);
            $tarif_konsultasi = $tampil['tarif_konsultasi'];
            $total_tk = $total_tk + $tarif_konsultasi;
            $biaya_tindakan = $tampil['biaya_tindakan'];
            $total_bt = $total_bt + $biaya_tindakan;
        }
        $sql_resep = mysql_query("select sum(harga) as total_harga from mendapatkan, memeriksa where memeriksa.id_resep = mendapatkan.id_resep and memeriksa.tanggal >= '$awal' and memeriksa.tanggal <= '$akhirbaru'");
        $dtresep = mysql_fetch_array($sql_resep);
        $total_resep = $dtresep['total_harga'];
        ?>
    <h1>Data Penghasilan Klinik <?php echo $awal;?> - <?php echo $akhir; ?></h1></td>
    <form method="post" action="cetaklaporan.php">
    <table width="100%" border="0" cellspacing="0" cellpadding="5">
    </thead>
        <tbody>
            <tr>
                <td>Jumlah Pasien</td>
                <td>: <input type="text" name="" placeholder="Jumlah Pasien" readonly="readonly" value="<?php echo $jumlahpasien; ?>" size="50"></td>
            </tr>
            <tr> 
                <td>Resep Terjual</td>
                <td>: <input type="text" name="" placeholder="Jumlah Resep yang terjual" readonly="readonly" value="<?php echo $jumlahresep; ?>" size="50"> </td>
            </tr>
            <tr>
                <td>Pemasukan Tarif Konsultasi</td>
                <td>: <input type="text" name="tarif_konsultasi" placeholder="Tarif Konsultasi" readonly="readonly" value="<?php echo $total_tk; ?>" size="50"> </td>
            </tr>
            <tr>
                <td>Tarif Tindakan </td>
                <td>: <input type="text" name="biaya_tindakan" placeholder="Tarif Tindakan" readonly="readonly" value="<?php echo $total_bt; ?>" size="50"></td>
            </tr>
            <tr>
                <td>Biaya Resep</td>
                <td>: <input type="text" name="harga" placeholder="Biaya Resep atau Obat" readonly="readonly" value="<?php echo $total_resep; ?>" size="50"> </td>
            </tr>
            <tr>
                <td>Total</td>
                <td>: <input type="text" name="total_harga" placeholder="Total Keseluruhan" readonly="readonly" value="<?php
                    $all = $total_tk + $total_bt + $total_resep;
                    echo $all;
                ?>" size="50"></td>
            </tr>
            <tr>
                <td>
                    <a href="cetaklaporan.php?aw=<?php echo $awal; ?>&ak=<?php echo $akhir; ?>&akb=<?php echo $akhirbaru; ?>" target='_blank'>
                        Cetak Laporan
                    </a>
                </td>
                <td></td>
            </tr>
        </tbody>
    </table>
    </form>
    <?php
    }else{
        echo "<h1>Data Penghasilan Klinik $awal - $akhir </h1></td>
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
            <tr><td>DATA NOT FOUND !</td></tr></table>";
    }
    }?>
     </div>
</div>
<div id="footer">&copy; FNF 2016</div>
</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>