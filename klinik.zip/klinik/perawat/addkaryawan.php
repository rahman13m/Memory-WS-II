<?php  
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){
?>
<html>
<title>TAMBAH DATA KARYAWAN</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
	<div id="wrapper">
		<div id="header">
			<div class="logo">
				<center><img src="1.png" width="100px" height="100px" /></center>
			</div>
			<div class="banner">
			<font size="6">KLINIK SYAHRIAL MEDICA</font><br />
			<font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
				<strong>Phone:</strong>0813-7214-0750
			</div>
		</div>
	<div id="menu">
		<a href="tampildatapasien.php">PASIEN</a>
		<a href="tampildatakaryawan.php">KARYAWAN</a>
		<a href="tampildatapendaftar.php">PENDAFTARAN</a>
		<a href="tampildatapembayar.php">PEMBAYARAN</a>
   		<a href="penghasilan.php">PENGHASILAN</a>
		<a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
	</div>
	<div id="content">
		<div class="left-menu">
			<b><u>KARYAWAN</u></b>
      		<ul class="external-link">
        		<li><a href="tampildatakaryawan.php">Tampil Data Karyawan</a></li>
        		<li><a href="addkaryawan.php">Tambah Data Karyawan</a></li>
      </ul>
		</div>
	<div class="page">
		<h1>Tambah Data Karyawan</h1>
<form action="fungsiaddkaryawan.php" method="post">
	<table width="100%" border="0" cellspacing="0" cellpadding="5">
		<tbody>
			<tr>
				<td>ID Karyawan</td>
				<td>: <input type="text" name="id_karyawan" placeholder="ID KARYAWAN" size="50" required> </td>
			</tr>
			<tr>
				<td>Nama Karyawan</td>
				<td>: <input type="text" name="namakaryawan" placeholder="NAMA KARYAWAN" size="50" required> </td>
			</tr>
			<tr>
				<td>Password</td>
				<td>: <input type="password" name="password" placeholder="Masukkan Password Anda" size="50" required> </td>
			</tr>
			<tr>
				<td>Ulangi Password</td>
				<td>: <input type="password" name="password2" placeholder="Ulangi Password Anda Disini" size="50" required> </td>
			</tr>
			<tr>
				<td>Jenis User</td>
				<td>: 
					<input type="radio" name="user" value="dokter" size="25"> Dokter
					<input type="radio" name="user" value="perawat" size="25"> Perawat
					<input type="radio" name="user" value="apoteker" size="25"> Apoteker
				</td>
			</tr>
			<tr>
				<td>No. Telp</td>
				<td>: <input type="text" name="no_telp" placeholder="Nomor Telepon" size="50" required> </td>
			</tr>
			<tr>
				<td>Spesialis</td>
				<td>:
					<input type="radio" name="spesialis" value="umum" size="25"> Umum
					<input type="radio" name="spesialis" value="gigi" size="25"> Gigi
					<input type="radio" name="spesialis" value="bukan dokter" size="25"> Bukan Dokter
				 </td>
			</tr>
			<tr>
				<td>Tarif Konsultasi</td>
				<td>: Rp. <input type="text" name="tarif_konsultasi" placeholder="Jika bukan dokter, isi dengan 0" size="46"> </td>
			</tr>
			<tr>
				<td>Status Kerja</td>
				<td>: 
					<input type="radio" name="status" value="aktif" size="25"> Aktif
					<input type="radio" name="status" value="tidak aktif" size="25"> Tidak Aktif
				</td>
			</tr>
			<tr>  
				<td colspan="2">
					<input type="submit" name="submit"value="submit">
					<input type="reset">
				</td>  
			</tr> 
		</tbody>
	</table>
</form>	
	</div>
</div>
<div id="footer">&copy; FNF 2016</div>
</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>