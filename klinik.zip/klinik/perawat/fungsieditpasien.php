<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){

if(isset($_POST['simpan']))
{
	include 'koneksi.php';
   	$no_medicalrecord = $_POST['no_medicalrecord'];
	$no_rak = $_POST['no_rak'];
    $nama = $_POST['nama'];  
    $alamat = $_POST['alamat'];  
    $no_telp= $_POST['no_telp'];
	$tanggal_lahir = $_POST['tanggal_lahir'];
    $gender = $_POST['gender']; 

    $update = mysql_query("UPDATE `db_klinik`.`pasien` SET `nama` = '$nama',`alamat` = '$alamat',`no_medicalrecord` = '$no_medicalrecord', `no_rak` = '$no_rak', `no_telp` = '$no_telp', `tanggal_lahir` = '$tanggal_lahir', `gender` = '$gender' WHERE `pasien`.`no_medicalrecord` = '$no_medicalrecord'");  
    if($update){  
        echo("  
            <script>alert('Data [ $nama ] berhasil di Update')</script>  
            <meta http-equiv=refresh content='0; url=tampildatapasien.php' >  
        ");  
    }else{  
        echo("  
            <script>alert('ERROR | Data gagal di update')</script>  
            <meta http-equiv=refresh content='0; url=editdatapasien.php?id='$id'' >  
        ");   
    }  
}
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>