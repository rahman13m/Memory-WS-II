<?php
include "koneksi.php";
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){
?>
<html>
<title>PENDAFTARAN</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
  <div id="wrapper">
    <div id="header">
      <div class="logo">
        <center><img src="1.png" width="100px" height="100px" /></center>
      </div>
      <div class="banner">
      <font size="6">KLINIK SYAHRIAL MEDICA</font><br />
      <font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
        <strong>Phone:</strong>0813-7214-0750
      </div>
    </div>
  <div id="menu">
    <a href="tampildatapasien.php">PASIEN</a>
    <a href="tampildatakaryawan.php">KARYAWAN</a>
    <a href="tampildatapendaftar.php">PENDAFTARAN</a>
    <a href="tampildatapembayar.php">PEMBAYARAN</a>
    <a href="penghasilan.php">PENGHASILAN</a>
    <a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
  </div>
  <div id="content">
    <div class="left-menu">
      <b><u>PENDAFTAR</u></b>
      <ul class="external-link">
        <li><a href="tampildatapendaftar.php"> Tampil Data Pendaftaran</a></li>
        <li><a href="addpasien.php"> Tambah Data Pasien</a></li>
      </ul> 
    </div>
  <div class="page">
    <h1>PENDAFTARAN PASIEN</h1>
<?php
  include "koneksi.php";
    $no_medicalrecord = $_GET['id'];
  $show = mysql_query("SELECT * FROM pasien WHERE no_medicalrecord='$no_medicalrecord'");
  if(mysql_num_rows($show) == 0)
    {   
    }
    else {
        $ed = mysql_fetch_assoc($show);   
    }
?>  
<form method="post" action="fungsieditdaftar.php">
<input type="hidden" name="tanggal" size="50" value="<?php
            $tanggal= mktime(date("m"),date("d"),date("Y"));
            echo date("Y/m/d", $tanggal)." ";
            date_default_timezone_set('Asia/Jakarta');
            $jam=date("H:i:s");
            echo $jam;
            ?>" readonly="readonly" required>
<input type="hidden" name="no_resep" placeholder="No Medica Record" value="RS000<?php
        $sql = mysql_query("SELECT * FROM `memeriksa`");
        $jmlh = mysql_num_rows($sql);
        echo $jmlh+1;
        ?>" readonly="readonly" size="23">
<table width="100%" border="0" cellspacing="0" cellpadding="5">  
  <tbody>
  <tr>
        <td>No Medical Record</td>
        <td>: <input type="text" name="no_medicalrecord" placeholder="No Medica Record" size="23" readonly="readonly" value="<?php echo $ed['no_medicalrecord']; ?>"required> &nbsp; No.Rak : <input type="text" name="no_rak" placeholder="No.Rak" size="9" value="<?php echo $ed['no_rak']; ?>"required> </td>
      </tr>
      <tr>
        <td>Nama Pasien</td>
        <td>: <input type="text" name="nama" placeholder="Nama Pasien" size="50" readonly="readonly" value="<?php echo $ed['nama']; ?>"required> </td>
      </tr>
      <tr>
        <td>Alamat</td>
        <td>: <input type="text" name="alamat" placeholder="Alamat Pasien" size="50" readonly="readonly" value="<?php echo $ed['alamat']; ?>"required> </td>
      </tr>
      <tr>
        <td>Nomor Telepon</td>
        <td>: <input type="text" name="no_telp" placeholder="Nomor Telepon Pasien" readonly="readonly" size="50" value="<?php echo $ed['no_telp']; ?>"required></td>
      </tr>
      <tr>
        <td>Tanggal Lahir</td>
        <td>: <input type="text" name="tanggal_lahir" placeholder="Tanggal Lahir Pasien" size="50" readonly="readonly" value="<?php echo $ed['tanggal_lahir']; ?>"required> </td>
      </tr>
      <tr>
        <td>Jenis Kelamin</td>
        <td>:
        <?php  
        if($ed['gender'] == "laki-laki"){
        echo"<input type='radio' name='gender' value='laki-laki'  size='25' checked> Laki-Laki
        <input type='radio' name='gender' value='perempuan' size='25'disabled > Perempuan";
        }else{
        echo"<input type='radio' name='gender' value='laki-laki' size='25'disabled > Laki-Laki
        <input type='radio' name='gender' value='perempuan' size='25' checked> Perempuan";
        } ?>
        </td>
      </tr>
      <tr>
      <td>Dokter</td>
      <td>: <select name="id_karyawan" required>
      <option value=""> Pilih Nama Dokter</option>
      <?php
      if($q=mysql_query("select nama_karyawan, id_karyawan, spesialis from karyawan where user = 'dokter' and status = 'aktif' order by id_karyawan asc")){
          if (mysql_num_rows($q) > 0) {
            while ($dtq=mysql_fetch_array($q)) {
              echo "<option value='".$dtq['id_karyawan']."'>".$dtq['nama_karyawan']." (".$dtq['spesialis'].")</option>";
            }
          }else{
            echo "<option value=''>Data Karyawan Kosong</option>";
          }
        }
      ?>
      </td>
      <tr>  
        <td>
          <input type="submit" name="submit" value="submit">
        </td><td></td>
        </tr> 
  </tbody>    
</table>  
</form>
  </div>
</div>
<div id="footer">&copy; FNF 2016</div>
</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>