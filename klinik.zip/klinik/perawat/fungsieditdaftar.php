<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){

if(isset($_POST['submit']))
{
	include "koneksi.php";
	$id_karyawan = $_POST['id_karyawan'];
	$namapasien = $_POST['nama'];
    $no_medicalrecord = $_POST['no_medicalrecord'];
    $tanggal = $_POST['tanggal'];
    $no_resep = $_POST['no_resep'];
    $poli = $_POST['spesialis'];

	$link = mysql_connect('localhost', 'root', '');
    $db_selected = mysql_select_db('db_klinik');
    $add = mysql_query("INSERT INTO `db_klinik`.`memeriksa` (`tanggal`, `status_pembayaran` ,`id_karyawan`, `no_medicalrecord`, `status_diagnosa`, `id_resep`, `status_pembuatan`) VALUES ('$tanggal', 'belum dibayar' ,'$id_karyawan', '$no_medicalrecord', 'belum dicek', '$no_resep', 'belum dibuat')");  
    if($add){
        echo("  
            <script>alert('Data [ $namapasien ] berhasil ditambahkan')</script>  
            <meta http-equiv=refresh content='0; url=tampildatapendaftar.php' >  
        ");  
    }
    else{  
        echo("  
            <script>alert('ERROR | Data gagal di input')</script>  
            <meta http-equiv=refresh content='0; url=daftar.php?id=$no_medicalrecord' >  
        ");   
    }
}
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>