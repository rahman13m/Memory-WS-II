<?php
include "koneksi.php";
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){
?>
<html>
<title>PEMBAYARAN</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
	<div id="wrapper">
		<div id="header">
			<div class="logo">
				<center><img src="1.png" width="100px" height="100px" /></center>
			</div>
			<div class="banner">
			<font size="6">KLINIK SYAHRIAL MEDICA</font><br />
			<font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
				<strong>Phone:</strong>0813-7214-0750
			</div>
		</div>
	<div id="menu">
		<a href="tampildatapasien.php">PASIEN</a>
		<a href="tampildatakaryawan.php">KARYAWAN</a>
		<a href="tampildatapendaftar.php">PENDAFTARAN</a>
		<a href="tampildatapembayar.php">PEMBAYARAN</a>
    	<a href="penghasilan.php">PENGHASILAN</a>
		<a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
	</div>
	<div id="content">
		<div class="left-menu">
			<b><u>PEMBAYARAN</u></b>
			<ul class="external-link">
        <li><a href="tampildatapembayar.php"> Tampil Data Pembayar</a></li>
      </ul> 
		</div>
	<div class="page">
	<h1>Pembayaran </h1>
	<?php
  	include "koneksi.php";
    $no_medicalrecord = $_GET['idp'];
    $id_karyawan = $_GET['idk'];
    $id_resep = $_GET['idr'];
  	$show = mysql_query("select pasien.nama, pasien.gender, karyawan.tarif_konsultasi, memeriksa.biaya_tindakan, memeriksa.id_karyawan, memeriksa.no_medicalrecord, karyawan.nama_karyawan, memeriksa.id_resep, memeriksa.status_pembayaran from karyawan, pasien, memeriksa where memeriksa.id_karyawan = karyawan.id_karyawan and memeriksa.no_medicalrecord = pasien.no_medicalrecord and memeriksa.id_karyawan = '$id_karyawan' and memeriksa.no_medicalrecord = '$no_medicalrecord' and memeriksa.id_resep = '$id_resep'");
  	if(mysql_num_rows($show) == 0)
    	{   
    	}
    else {
        $ed = mysql_fetch_assoc($show);   
    }
    ?>
    <form method="post" action='ubahstatuspembayaran.php'>
    <input type="hidden" value="<?php echo $ed['id_karyawan']?>" name="id_karyawan">
    <input type="hidden" value="<?php echo $ed['no_medicalrecord']?>" name="no_medicalrecord">
    <input type="hidden" value="<?php echo $ed['id_resep']?>" name="id_resep">
	<table width="100%" border="0" cellspacing="0" cellpadding="5">
		<tbody>
			<tr>
				<td>Nama Pasien</td>
				<td> : <input type="text" name="nama" placeholder="Nama Pasien" value="<?php echo $ed['nama']; ?>"size="50" readonly="readonly"></td>
			</tr>
			<tr>
				<td>Jenis Kelamin</td>
				<td>:
				<?php  
			        if($ed['gender'] == "laki-laki"){
			        echo"<input type='radio' name='gender' value='laki-laki'  size='25' checked> Laki-Laki
			        <input type='radio' name='gender' value='perempuan' size='25'disabled > Perempuan";
			        }else{
			        echo"<input type='radio' name='gender' value='laki-laki' size='25'disabled > Laki-Laki
			        <input type='radio' name='gender' value='perempuan' size='25' checked> Perempuan";
			    } ?>
				</td>
			</tr>
			<tr> 
				<td>Dokter</td>
				<td>: <input type="text" name="nama_karyawan" placeholder="Nama Dokter" value="<?php echo $ed['nama_karyawan']; ?>" readonly="readonly" size="50"> </td>
			</tr>
			<tr>
				<td><strong>BIAYA</strong></td><td></td>
			</tr>
			<tr>
				<td>Tarif Konsultasi</td>
				<td>: Rp. <input type="text" name="tarif_konsultasi" placeholder="Tarif Konsultasi" size="7" value="<?php echo $ed['tarif_konsultasi']; ?>" readonly="readonly"></td>
			</tr>
			<tr>
				<td>Tarif Tindakan </td>
				<td>: Rp. <input type="text" name="biaya_tindakan" placeholder="Tarif Tindakan" size="7" value="<?php echo $ed['biaya_tindakan']; ?>" readonly="readonly"></td>
			</tr>
			<tr>
				<td>Biaya Resep</td>
				<td>: Rp. <input type="text" name="harga" placeholder="Biaya Resep atau Obat" size="7" readonly="readonly" value="<?php
					$sql = "select * from mendapatkan where id_resep = '$id_resep'";
					$query = mysql_query($sql);
					$total =0;
					while($data = mysql_fetch_array($query)){
						$subtotal=$data['harga'];
						$total = $total + $subtotal;
					}
					echo $total;
				?>"> </td>
			</tr>
			<tr>
				<td>Total</td>
				<td>: Rp. <input type="text" name="total_harga" placeholder="Total Keseluruhan" size="7" readonly="readonly" value="<?php 
					$tarif_konsultasi = $ed['tarif_konsultasi'];
					$biaya_tindakan = $ed['biaya_tindakan'];
					$biaya_resep = $total;
					$totalharga = $tarif_konsultasi + $biaya_tindakan + $biaya_resep;
					echo $totalharga;
				?>">
				<?php 
					if($ed['status_pembayaran']=="belum dibayar"){
						echo ("<input type='Submit' value='Lunas' name='Lunas'>");
					}elseif($ed['status_pembayaran']=="sudah dibayar") {
						echo ("<a href='cetakstruk.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep' target='_blank'>CETAK STRUK</a>");
					}
				?>
					 
				</td>
			</tr>
		</tbody>
	</table>
	</form>
	</div>
<div id="footer">&copy; FNF 2016</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>