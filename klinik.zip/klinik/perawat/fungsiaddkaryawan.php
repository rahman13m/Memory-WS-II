<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){

if(isset($_POST['submit']))
{
	include "koneksi.php";
	$id_karyawan = $_POST['id_karyawan'];
    $namakaryawan = $_POST['namakaryawan'];  
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    $no_telp= $_POST['no_telp'];
	$spesialis = $_POST['spesialis'];
	$tarif_konsultasi = $_POST['tarif_konsultasi'];
	$status = $_POST['status'];
    $user = $_POST['user'];  

    if ($password == $password2) {
	$link = mysql_connect('localhost', 'root', '');
    $db_selected = mysql_select_db('db_klinik');
    $add = mysql_query("INSERT INTO `db_klinik`.`karyawan` (`nama_karyawan`, `id_karyawan`, `password`, `no_telp`, `spesialis`, `tarif_konsultasi`, `status`, `user`) VALUES ('$namakaryawan', '$id_karyawan', '$password', '$no_telp', '$spesialis', '$tarif_konsultasi', '$status', '$user')");  
    if($add){  
        echo("  
            <script>alert('Data [ $namakaryawan ] berhasil ditambahkan')</script>  
            <meta http-equiv=refresh content='0; url=tampildatakaryawan.php' >  
        ");  
    }
    else{  
        echo("  
            <script>alert('ERROR | Data gagal di input')</script>  
            <meta http-equiv=refresh content='0; url=addkaryawan.php' >  
        ");   
    }
    }else{
        echo("  
            <script>alert('ERROR | Password tidak valid')</script>  
            <meta http-equiv=refresh content='0; url=addkaryawan.php' >  
        ");
    }
}
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>