<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){

if(isset($_GET['id'])){	
include "koneksi.php"; 
$id = $_GET['id'];  
$nama=$_GET['nama'];  
$cek = mysql_query("SELECT id_karyawan FROM karyawan WHERE id_karyawan='$id'") or die(mysql_error());
if(mysql_num_rows($cek) == 0)
	{
		echo '<script>window.history.back()</script>';
	}	
else
	{
		$del = mysql_query("DELETE FROM `db_klinik`.`karyawan` WHERE `karyawan`.`id_karyawan` = '$id'");
		if($del){  
		echo("  
			<script>alert('Data [$nama] berhasil dihapus')</script>  
			<meta http-equiv=refresh content='0; url=tampildatakaryawan.php'>  
        ");
		}
		else {  
        echo("  
            <script>alert('ERROR | Data gagal di input')</script>  
            <meta http-equiv=refresh content='0; url=tampildatakaryawan.php' >  
        ");
		}
	}
}
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>