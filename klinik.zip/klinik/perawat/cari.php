<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){

	$kode=$_POST['kode'];
	$pilihpasien=$_POST['pilihpasien'];

	if ($pilihpasien == 'nama') {
		$sql = "select * from pasien where nama like '%$kode%' ";
	} else if ($pilihpasien == 'alamat') {
		$sql = "select * from pasien where alamat like '%$kode%'";
	} else if ($pilihpasien == 'tgllahir'){
		$sql = "select * from pasien where tanggal_lahir like '%$kode%'";
	}else{
		echo "<script>alert('Kategori Belum Dipilih!')</script>
		<meta http-equiv=refresh content='0; url=tampildatapasien.php' >";
	}

	$result = mysql_query($sql);
	if(mysql_num_rows($result) > 0){
		?>
		<table width='100%' border='0' cellspacing='0' cellpadding='5'> 
		<thead> 
        	<th>No. Medical Record</th>  
        	<th>Nama</th>  
        	<th>Tanggal Lahir</th>  
        	<th>Alamat</th>  
        	<th>No. Telp</th>
			<th>Gender</th>
		</thead>
			<?php
			while($tampil = mysql_fetch_array($result)){?>
			<tr>
				<td><?php echo $tampil['no_medicalrecord'];?></td>
				<td><?php echo $tampil['nama'];?></td>
				<td><?php echo $tampil['tanggal_lahir'];?></td>
				<td><?php echo $tampil['alamat'];?></td>
				<td><?php echo $tampil['no_telp'];?></td>
				<td><?php echo $tampil['gender'];?></td>
			</tr>
			<?php }?>
		</table>
		<?php
	}else{
		echo 'Data not found!'; 
	}
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>