<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){

if(isset($_POST['UPDATE']))
{
	include 'koneksi.php';
	$id_karyawan = $_POST['id_karyawan'];	// yang pake $ isi nama variable yang dalem, []/index buat ke name input  text html sebelah
    $nama_karyawan = $_POST['namakaryawan'];  
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    $user = $_POST['user'];
	$no_telp = $_POST['no_telp'];
	$spesialis = $_POST['spesialis'];
	$tarif_konsultasi = $_POST['tarif_konsultasi'];
    $status = $_POST['status'];

    if ($password == $password2) {
    $update = mysql_query("UPDATE `db_klinik`.`karyawan` SET `nama_karyawan` = '$nama_karyawan', `id_karyawan` = '$id_karyawan', `password` = '$password', `no_telp` = '$no_telp', `spesialis` = '$spesialis', `tarif_konsultasi` = '$tarif_konsultasi', `status` = '$status', `user` = '$user' WHERE `karyawan`.`id_karyawan` = '$id_karyawan'");  
    if($update){  
        echo("  
            <script>alert('Data [ $nama_karyawan ] berhasil di Update')</script>  
            <meta http-equiv=refresh content='0; url=tampildatakaryawan.php' >  
        ");  
    }else{  
        echo("  
            <script>alert('ERROR | Data gagal di update')</script>  
            <meta http-equiv=refresh content='0; url=editkaryawan.php?id='$id' >  
        ");   
    }
    }else{
        echo("  
            <script>alert('ERROR | Verifikasi password salah')</script>  
            <meta http-equiv=refresh content='0; url=editkaryawan.php?id='$id' >  
        ");
    }  
}
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>