<?php
include "koneksi.php";
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){
?>
<html>
<title>DATA PENDAFTAR</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
  <div id="wrapper">
    <div id="header">
      <div class="logo">
        <center><img src="1.png" width="100px" height="100px" /></center>
      </div>
      <div class="banner">
      <font size="6">KLINIK SYAHRIAL MEDICA</font><br />
      <font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
        <strong>Phone:</strong>0813-7214-0750
      </div>
    </div>
  <div id="menu">
    <a href="tampildatapasien.php">PASIEN</a>
    <a href="tampildatakaryawan.php">KARYAWAN</a>
    <a href="tampildatapendaftar.php">PENDAFTARAN</a>
    <a href="tampildatapembayar.php">PEMBAYARAN</a>
    <a href="penghasilan.php">PENGHASILAN</a>
    <a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
  </div>
  <div id="content">
    <div class="left-menu">
      <b><u>PENDAFTAR</u></b>
      <ul class="external-link">
        <li><a href="tampildatapendaftar.php"> Tampil Data Pendaftaran</a></li>
      </ul> 
    </div>
  <div class="page">
    <h1>Data Pendaftaran Klinik Syahrial Medica</h1>
<?php echo("
    <table width='100%' border='0' cellspacing='0' cellpadding='5'>  
      <thead>  
        <th>No.</th>  
        <th>ID Karyawan</th>  
        <th>Nama Karyawan</th>  
        <th>Nama Pasien</th>  
        <th>Nomor Medical Record</th>
        <th>Tanggal</th>
      </thead>  
      <tbody>  
      ");  
      $q = mysql_query("select karyawan.nama_karyawan, pasien.nama, memeriksa.tanggal, memeriksa.id_karyawan, memeriksa.no_medicalrecord from karyawan, pasien, memeriksa where karyawan.id_karyawan = memeriksa.id_karyawan and pasien.no_medicalrecord = memeriksa.no_medicalrecord and memeriksa.status_pembayaran = 'belum dibayar' ORDER BY `memeriksa`.`tanggal` ASC");  
      $num = 1;
      while ($dat = mysql_fetch_array($q)){  
      echo("                    
      <tr>  
        <td align=center>".$num++."</td>  
        <td align=center>$dat[id_karyawan]</td>  
        <td align=center>$dat[nama_karyawan]</td>  
        <td align=center>$dat[nama]</td>  
        <td align=center>$dat[no_medicalrecord]</td>
        <td align=center>$dat[tanggal]</td>
      </tr>  
      ");  
      }  
      echo("   
      </tbody>  
    </table>              
"); ?>  
  </div>
</div>
<div id="footer">&copy; FNF 2016</div>
</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>