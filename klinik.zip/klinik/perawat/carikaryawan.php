<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){

	$kode=$_POST['kode'];
	$pilihkaryawan=$_POST['pilihkaryawan'];
	
	if ($pilihkaryawan == 'nama') {
		$sql = "select * from karyawan where nama_karyawan like '%$kode%'";
	} else if ($pilihkaryawan == 'user') {
		$sql = "select * from karyawan where user like '%$kode%'";
	} else if ($pilihkaryawan == 'spesialis'){
		$sql = "select * from karyawan where spesialis like '%$kode%'";
	}else{
		echo "<script>alert('Kategori Belum Dipilih!')</script>
		<meta http-equiv=refresh content='0; url=tampildatapasien.php' >";
	}

	$result = mysql_query($sql);
	if(mysql_num_rows($result) > 0){
		?>
		<table width='100%' border='0' cellspacing='0' cellpadding='5'> 
		<thead>
        	<th>ID karyawan</th>  
        	<th>Nama karyawan</th>  
        	<th>Password</th>  
        	<th>User</th>  
        	<th>No. Telp</th>
			<th>Spesialis</th>
			<th>Tarif Konsultasi</th>
			<th>Status</th>
		</thead>
			<?php
			while($tampil = mysql_fetch_array($result)){?>
			<tr>
				<td><?php echo $tampil['id_karyawan'];?></td>
				<td><?php echo $tampil['nama_karyawan'];?></td>
				<td><?php echo $tampil['password'];?></td>
				<td><?php echo $tampil['user'];?></td>
				<td><?php echo $tampil['no_telp'];?></td>
				<td><?php echo $tampil['spesialis'];?></td>
				<td><?php echo $tampil['tarif_konsultasi'];?></td>
				<td><?php echo $tampil['status'];?></td>
			</tr>
			<?php }?>
		</table>
		<?php
	}else{
		echo 'Data not found!'; 
	}
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>