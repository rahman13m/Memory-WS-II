<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){

if(isset($_POST['submit']))
{
	include "koneksi.php";
	$no_medicalrecord = $_POST['no_medicalrecord'];
	$no_rak = $_POST['no_rak'];
    $nama = $_POST['nama'];  
    $alamat = $_POST['alamat'];  
    $no_telp= $_POST['no_telp'];
	$tanggal_lahir = $_POST['tanggal_lahir'];
    $gender = $_POST['gender'];  
	
	$link = mysql_connect('localhost', 'root', '');
    $db_selected = mysql_select_db('db_klinik');
    $add = mysql_query("INSERT INTO `db_klinik`.`pasien` (`no_medicalrecord`, `nama`, `alamat`, `no_telp`, `gender`, `no_rak`, `tanggal_lahir`) VALUES ('$no_medicalrecord', '$nama', '$alamat', '$no_telp', '$gender', '$no_rak', '$tanggal_lahir')");
    if($add){  
		include "tampildatapasien.php";
        echo("  
            <script>alert('Data [ $nama ] berhasil ditambahkan')</script>  
        ");  
    }
    else{  
        echo("  
            <script>alert('ERROR | Data gagal di input')</script>  
            <meta http-equiv=refresh content='0; url='addpasien.php'>  
        ");   
    }
}
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>