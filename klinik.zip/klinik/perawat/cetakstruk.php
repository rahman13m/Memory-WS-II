<?php
include "koneksi.php";
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){

include "koneksi.php";
include "fpdf/fpdf.php";
$idk = $_GET['idk'];
$idp = $_GET['idp'];
$idr = $_GET['idr'];
$pdf=new FPDF('P', 'mm', 'A4');
$pdf->setMargins(5,5,5);
$pdf->AddPage();
$sql=mysql_query("select karyawan.id_karyawan, karyawan.nama_karyawan, karyawan.tarif_konsultasi, pasien.no_medicalrecord, pasien.nama, memeriksa.id_resep, memeriksa.biaya_tindakan, memeriksa.tanggal, memeriksa.jenis_penyakit, memeriksa.jenis_pengobatan, memeriksa.tindakan, memeriksa.keterangan_resep FROM pasien, memeriksa, karyawan WHERE memeriksa.id_karyawan = karyawan.id_karyawan and memeriksa.no_medicalrecord = pasien.no_medicalrecord and memeriksa.id_karyawan = '$idk' and memeriksa.no_medicalrecord = '$idp' and memeriksa.id_resep = '$idr'");
$data=mysql_fetch_array($sql);
$pdf->Image('1.png',10,12,30);
$pdf->setXY(65,20);
$pdf->setfont('Arial', 'B', '18');
$pdf->cell(50,10,'KLINIK SYAHRIAL MEDICA');
$pdf->setXY(20,40);
$pdf->setfont('Arial', 'B', '13');
$pdf->cell(20,6,'Tanggal');$pdf->cell(50,6,': '.$data['tanggal']);
$pdf->setXY(135,40);
$pdf->cell(30,6,'Nomor Resep');$pdf->cell(50,6,': '.$data['id_resep']);
$pdf->setfont('Arial', '', '12');
$pdf->setXY(50,50);
$pdf->cell(30,6,'Nama Pasien');$pdf->cell(30,6,': '.$data['nama']);
$pdf->setXY(50,56);
$pdf->cell(30,6,'Nama Dokter');$pdf->cell(50,6,': '.$data['nama_karyawan']);
$pdf->setXY(50,62);
$pdf->cell(30,6,'Diagnosa');$pdf->cell(150,6,': '.$data['jenis_penyakit']);
$pdf->setXY(50,68);
$pdf->cell(30,6,'Pengobatan');$pdf->cell(150,6,': '.$data['jenis_pengobatan']);
$pdf->setXY(50,74);
$pdf->cell(30,6,'Tindakan');$pdf->cell(150,6,': '.$data['tindakan']);
$pdf->setfont('Arial', 'B', '14');
$pdf->setXY(20,90);
$pdf->cell(30,6,'Obat yang Dibeli :');
$y_initial=100;
$y_axis1=100;
$pdf->setfont('Arial', 'B', '11');
$pdf->setfillcolor(255,255,255);
$pdf->setY($y_axis1);
$pdf->setX(20);
$pdf->cell(10,6,'No',1,0,'C',1);
$pdf->cell(20,6,'ID Obat',1,0,'C',1);
$pdf->cell(25,6,'Nama Obat',1,0,'C',1);
$pdf->cell(28,6,'Harga Satuan',1,0,'C',1);
$pdf->cell(15,6,'Jumlah',1,0,'C',1);
$pdf->cell(52,6,'Dosis',1,0,'C',1);
$pdf->cell(20,6,'Harga',1,0,'C',1);
$no=0;
$row=6;
$totalharga=0;
$y=$y_initial+$row;
$obat=mysql_query("select * from mendapatkan where id_resep = '$idr' and no_medicalrecord = '$idp'");
while ($daftar=mysql_fetch_array($obat)) {
	$no++;
	$pdf->setY($y);
	$pdf->setX(20);
	$pdf->setfont('Arial', '', '11');
	$pdf->cell(10,6,$no,1,0,'C',1);
	$pdf->cell(20,6,$daftar['id_obat'],1,0,'C',1);
	$pdf->cell(25,6,$daftar['namaobat'],1,0,'C',1);
	$pdf->cell(28,6,$daftar['hargasatuan'],1,0,'C',1);
	$pdf->cell(15,6,$daftar['jumlah'],1,0,'C',1);
	$pdf->cell(52,6,$daftar['dosis'],1,0,'C',1);
	$pdf->cell(20,6,$daftar['harga'],1,0,'R',1);
	$y=$y+$row;
	$subtotal=$daftar['harga'];
	$totalharga=$totalharga+$subtotal;
}
$all=$totalharga+$data['tarif_konsultasi']+$data['biaya_tindakan'];
$pdf->setXY(170,$y);
$pdf->cell(20,6,$totalharga,1,0,'R',1);
$pdf->setfont('Arial', 'B', '14');
$pdf->setXY(50,$y+20);
$pdf->cell(50,6,'Biaya Keseluruhan');
$pdf->setfont('Arial', '', '12');
$pdf->setXY(50,$y+26);
$pdf->cell(50,6,'1. Biaya Konsultasi');$pdf->cell(10,6,' : Rp. ');$pdf->cell(20,6,$data['tarif_konsultasi'],0,0,'R',0);
$pdf->setXY(50,$y+32);
$pdf->cell(50,6,'2. Biaya Tindakan');$pdf->cell(10,6,' : Rp. ');$pdf->cell(20,6,$data['biaya_tindakan'],0,0,'R',0);
$pdf->setXY(50,$y+38);
$pdf->cell(50,6,'3. Biaya Resep');$pdf->cell(10,6,' : Rp. ');$pdf->cell(20,6,$totalharga,0,0,'R',0);
$pdf->setXY(50,$y+44);
$pdf->cell(50,6,'4. Total');$pdf->cell(10,6,' : Rp. ');$pdf->cell(20,6,$all,0,0,'R',0);
$pdf->setXY(30,$y+60);
$pdf->cell(50,6,'Keterangan Resep');$pdf->cell(50,6,': '.$data['keterangan_resep']);
$tanggal= mktime(date("m"),date("d"),date("Y"));
$tgl=date("d-M-Y", $tanggal);
$pdf->setfont('Arial', 'B', '12');
$pdf->setXY(30,$y+80);
$pdf->cell(50,6,'Telah dibayar LUNAS sebesar Rp. '.$all.',- pada tanggal '.$tgl);
$pdf->setfont('Arial', 'B', '11');
$pdf->setXY(13,240);
$pdf->cell(50,6,'Kasir',0,0,'C',0);
$pdf->setXY(140,240);
$pdf->cell(50,6,'Pasien',0,0,'C',0);
$pdf->setXY(13,270);
$pdf->cell(50,6,'( '.$nama_karyawan.' )',0,0,'C',0);
$pdf->setXY(140,270);
$pdf->cell(50,6,'( '.$data['nama'].' )',0,0,'C',0);
$pdf->Output();
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>