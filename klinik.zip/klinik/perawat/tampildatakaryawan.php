<?php 
include "koneksi.php";
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){
?>
<html>
<title>DATA KARYAWAN</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
  <div id="wrapper">
    <div id="header">
      <div class="logo">
        <center><img src="1.png" width="100px" height="100px" /></center>
      </div>
      <div class="banner">
      <font size="6">KLINIK SYAHRIAL MEDICA</font><br />
      <font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
        <strong>Phone:</strong>0813-7214-0750
      </div>
    </div>
  <div id="menu">
    <a href="tampildatapasien.php">PASIEN</a>
    <a href="tampildatakaryawan.php">KARYAWAN</a>
    <a href="tampildatapendaftar.php">PENDAFTARAN</a>
    <a href="tampildatapembayar.php">PEMBAYARAN</a>
    <a href="penghasilan.php">PENGHASILAN</a>
    <a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
  </div>
  <div id="content">
    <div class="left-menu">
      <b><u>KARYAWAN</u></b>
      <ul class="external-link">
        <li><a href="tampildatakaryawan.php">Tampil Data Karyawan</a></li>
        <li><a href="addkaryawan.php">Tambah Data Karyawan</a></li>
      </ul>
    </div>
  <div class="page">
    <form method="post">
<table width="100%" border="0" cellspacing="0" cellpadding="5">
    <tbody>
      <tr>
        <td>
        Pencarian Karyawan Berdasarkan
        <select name="pilihkaryawan">
          <option value="pilihan">Pilihan</option>
            <option value="nama">Nama</option>
          <option value="user">Jabatan</option>
            <option value="spesialis">Spesialis</option>
        </select> : 
        <input type="text" name = "kode" placeholder="Pencarian" size="30" required>
        <input type="submit" name="search" value="search">
        </td>  
      </tr>
    </tbody>
  </table></form>
    <?php 
if(isset($_POST['search'])){
include "carikaryawan.php";
}else {
echo("
    <table width='100%' border='0' cellspacing='0' cellpadding='5'>  
      <thead>  
        <th>No.</th>  
        <th>ID Karyawan</th>  
        <th>Nama Karyawan</th>  
        <th>Jenis User</th>  
        <th>No. Telp</th>
    <th>Spesialis</th>
    <th>Tarif Konsultasi</th>
    <th>Status Kerja</th>
        <th>Pilihan</th>  
      </thead>  
      <tbody>  
      ");  
      $q = mysql_query("SELECT * FROM `karyawan` ORDER BY `id_karyawan` ASC");  
      $num = 1;
      while ($dat = mysql_fetch_array($q)){  
      echo("                    
      <tr>  
        <td align=center>".$num++."</td>  
        <td align=center>$dat[id_karyawan]</td>  
        <td align=center>$dat[nama_karyawan]</td>  
        <td align=center>$dat[user]</td>  
        <td align=center>$dat[no_telp]</td>
    <td align=center>$dat[spesialis]</td>
    <td align=center>$dat[tarif_konsultasi]</td>
    <td align=center>$dat[status]</td> 
        <td align=center>
      <a href=editkaryawan.php?id=$dat[id_karyawan]><button>Edit</button></a>
    </td>  
      </tr>  
      ");  
      }  
      echo("   
      </tbody>  
    </table>              
"); }?>  
  </div>
</div>
<div id="footer">&copy; FNF 2016</div>
</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>