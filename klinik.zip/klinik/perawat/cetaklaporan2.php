<?php
include "koneksi.php";
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){

class PDF extends FPDF
{
// Page header
function Header()
{
    // Logo
    $this->Image('1.png',10,6,30);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    $this->Cell(80);
    // Title
    $this->Cell(30,10,'Title',1,0,'C');
    // Line break
    $this->Ln(20);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

include "koneksi.php";
include "fpdf/fpdf.php";
$awal = $_GET['aw'];
$akhir = $_GET['ak'];
$akhirbaru = $_GET['akb'];
$pdf=new FPDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->setXY(40,35);
$pdf->setfont('Arial', 'B', '15');
$pdf->cell(20,6,'Laporan Pemasukan '.$awal.' Hingga '.$akhir);
$y_initial=60;
$y_axis1=60;
$row=6;
$totalharga=0;
$y=$y_initial+$row;
$pdf->setfont('Arial', 'B', '13');
$pdf->setXY(25,50);
$pdf->cell(30,6,'1. Jumlah Pasien');
$pdf->setfont('Arial', 'B', '12');
$pdf->setfillcolor(255,255,255);
$pdf->setXY(30,60);
$pdf->cell(30,6,'Tanggal',1,0,'C',1);
$pdf->cell(40,6,'Nama Pasien',1,0,'C',1);
$pdf->cell(30,6,'Nama Dokter',1,0,'C',1);
$pdf->cell(30,6,'Diagnosa',1,0,'C',1);
$pdf->cell(30,6,'Tarif',1,0,'C',1);
$tarif=0;
$sqlpasien = mysql_query("select karyawan.nama_karyawan, karyawan.tarif_konsultasi, DAYOFMONTH(tanggal) as hari, MONTHNAME(tanggal) as bulan, YEAR(tanggal) as tahun, pasien.nama, memeriksa.jenis_penyakit from karyawan, pasien, memeriksa where memeriksa.no_medicalrecord = pasien.no_medicalrecord and memeriksa.id_karyawan = karyawan.id_karyawan and memeriksa.status_pembayaran = 'sudah dibayar' and memeriksa.status_pembayaran = 'sudah dibayar' and memeriksa.tanggal >= '$awal' and memeriksa.tanggal <= '$akhirbaru' order by memeriksa.tanggal asc");
while ($cekpasien = mysql_fetch_array($sqlpasien)) {
	$pdf->setY($y);
	$pdf->setX(30);
	$pdf->setfont('Arial', '', '11');
	$pdf->cell(30,6,$cekpasien['hari'].' '.$cekpasien['bulan'].' '.$cekpasien['tahun'],1,0,'C',1);
	$pdf->cell(40,6,$cekpasien['nama'],1,0,'C',1);
	$pdf->cell(30,6,$cekpasien['nama_karyawan'],1,0,'C',1);
	$pdf->cell(30,6,$cekpasien['jenis_penyakit'],1,0,'C',1);
	$pdf->cell(30,6,$cekpasien['tarif_konsultasi'],1,0,'C',1);
	$y=$y+$row;
	$tarif_konsultasi=$cekpasien['tarif_konsultasi'];
	$tarif=$tarif+$tarif_konsultasi;
}
$pdf->setXY(160,$y);
$pdf->cell(30,6,$tarif,1,0,'C',1);
$pdf->setfont('Arial', 'B', '13');
$pdf->setXY(25,$y+12);
$pdf->cell(30,6,'2. Resep yang Terjual');
$pdf->setfont('Arial', 'B', '12');
$pdf->setfillcolor(255,255,255);
$pdf->setXY(30,$y+24);
$pdf->cell(30,6,'ID Resep',1,0,'C',1);
$pdf->cell(50,6,'Nama Pasien',1,0,'C',1);
$pdf->cell(40,6,'Nama Dokter',1,0,'C',1);
$pdf->cell(40,6,'Harga Resep',1,0,'C',1);
$y2=$y+30;
$sqlresep = mysql_query("select distinct memeriksa.id_resep, karyawan.nama_karyawan, memeriksa.total_harga, pasien.nama from mendapatkan, memeriksa, pasien, karyawan where memeriksa.id_resep = mendapatkan.id_resep and pasien.no_medicalrecord = memeriksa.no_medicalrecord and memeriksa.id_karyawan = karyawan.id_karyawan and memeriksa.status_pembayaran = 'sudah dibayar' and memeriksa.status_pembayaran = 'sudah dibayar' and memeriksa.tanggal >= '$awal' and memeriksa.tanggal <= '$akhirbaru' order by memeriksa.id_resep asc");
while ($cekresep = mysql_fetch_array($sqlresep)) {
	$pdf->setY($y2);
	$pdf->setX(30);
	$pdf->setfont('Arial', '', '11');
	$pdf->cell(30,6,$cekresep['id_resep'],1,0,'C',1);
	$pdf->cell(50,6,$cekresep['nama'],1,0,'C',1);
	$pdf->cell(40,6,$cekresep['nama_karyawan'],1,0,'C',1);
	$pdf->cell(40,6,$cekresep['total_harga'],1,0,'C',1);
	$y2=$y2+$row;
	$ttlrsp=$cekresep['total_harga'];
	$totalresep=$totalresep+$ttlrsp;
}
$pdf->setXY(150,$y2);
$pdf->cell(40,6,$totalresep,1,0,'C',1);
$pdf->setfont('Arial', 'B', '13');
$pdf->setXY(25,$y2+12);
$pdf->cell(30,6,'3. Obat yang Terjual');
$pdf->setfont('Arial', 'B', '12');
$pdf->setfillcolor(255,255,255);
$pdf->setXY(30,$y2+24);
$pdf->cell(20,6,'ID Resep',1,0,'C',1);
$pdf->cell(20,6,'ID Obat',1,0,'C',1);
$pdf->cell(40,6,'Nama Obat',1,0,'C',1);
$pdf->cell(20,6,'Jumlah',1,0,'C',1);
$pdf->cell(30,6,'Harga Satuan',1,0,'C',1);
$pdf->cell(30,6,'Total Harga',1,0,'C',1);
$y3=$y2+30;
$sqlobat = mysql_query("select distinct mendapatkan.id_resep, mendapatkan.id_obat, mendapatkan.namaobat, mendapatkan.jumlah, mendapatkan.hargasatuan, mendapatkan.harga from mendapatkan, memeriksa where memeriksa.id_resep = mendapatkan.id_resep and memeriksa.status_pembayaran = 'sudah dibayar' and memeriksa.status_pembayaran = 'sudah dibayar' and memeriksa.tanggal >= '$awal' and memeriksa.tanggal <= '$akhirbaru' order by mendapatkan.id_resep asc");
while ($cekobat = mysql_fetch_array($sqlobat)) {
	$pdf->setY($y3);
	$pdf->setX(30);
	$pdf->setfont('Arial', '', '11');
	$pdf->cell(20,6,$cekobat['id_resep'],1,0,'C',1);
	$pdf->cell(20,6,$cekobat['id_obat'],1,0,'C',1);
	$pdf->cell(40,6,$cekobat['namaobat'],1,0,'C',1);
	$pdf->cell(20,6,$cekobat['jumlah'],1,0,'C',1);
	$pdf->cell(30,6,$cekobat['hargasatuan'],1,0,'C',1);
	$pdf->cell(30,6,$cekobat['harga'],1,0,'C',1);
	$y3=$y3+$row;
	$ttlobt=$cekobat['harga'];
	$totalobt=$totalobt+$ttlobt;
}
$pdf->setXY(160,$y3);
$pdf->cell(30,6,$totalobt,1,0,'C',1);
$pdf->setfont('Arial', 'B', '13');
$pdf->setXY(25,$y3+12);
$pdf->cell(30,6,'4. Tindakan yang Dilakukan');
$pdf->setfont('Arial', 'B', '12');
$pdf->setfillcolor(255,255,255);
$pdf->setXY(30,$y3+24);
$pdf->cell(40,6,'Nama Pasien',1,0,'C',1);
$pdf->cell(30,6,'Nama Dokter',1,0,'C',1);
$pdf->cell(50,6,'Tindakan',1,0,'C',1);
$pdf->cell(40,6,'Biaya Tindakan',1,0,'C',1);
$y4=$y3+30;
$sqltindakan = mysql_query("select pasien.nama, karyawan.nama_karyawan, memeriksa.tindakan, memeriksa.biaya_tindakan from pasien, karyawan, memeriksa where memeriksa.no_medicalrecord = pasien.no_medicalrecord and memeriksa.status_pembayaran = 'sudah dibayar' and memeriksa.id_karyawan = karyawan.id_karyawan and memeriksa.status_pembayaran = 'sudah dibayar' and memeriksa.tanggal >= '$awal' and memeriksa.tanggal <= '$akhirbaru' order by memeriksa.id_resep asc");
while ($cektindakan = mysql_fetch_array($sqltindakan)) {
	$pdf->setY($y4);
	$pdf->setX(30);
	$pdf->setfont('Arial', '', '11');
	$pdf->cell(40,6,$cektindakan['nama'],1,0,'C',1);
	$pdf->cell(30,6,$cektindakan['nama_karyawan'],1,0,'C',1);
	$pdf->cell(50,6,$cektindakan['tindakan'],1,0,'C',1);
	$pdf->cell(40,6,$cektindakan['biaya_tindakan'],1,0,'C',1);
	$y4=$y4+$row;
	$ttltindakan=$cektindakan['biaya_tindakan'];
	$ttltndkn=$ttltndkn+$ttltindakan;
}
$pdf->setXY(150,$y4);
$pdf->cell(40,6,$ttltndkn,1,0,'C',1);
$pdf->setfont('Arial', 'B', '14');
$pdf->setXY(25,$y4+12);
$pdf->cell(30,6,'5. Pemasukan Keseluruhan');
$pdf->setfont('Arial', '', '12');
$pdf->setXY(40,$y4+24);
$pdf->cell(50,6,'1. Tarif Konsultasi');$pdf->cell(10,6,' : Rp. ');$pdf->cell(20,6,$tarif,0,0,'R',0);
$pdf->setXY(40,$y4+30);
$pdf->cell(50,6,'2. Obat yang terjual');$pdf->cell(10,6,' : Rp. ');$pdf->cell(20,6,$totalobt,0,0,'R',0);
$pdf->setXY(40,$y4+36);
$pdf->cell(50,6,'3. Tarif Tindakan');$pdf->cell(10,6,' : Rp. ');$pdf->cell(20,6,$ttltndkn,0,0,'R',0);
$allharga=$tarif+$totalobt+$ttltndkn;
$pdf->setXY(90,$y4+42);
$pdf->cell(10,6,' : Rp. ');$pdf->cell(20,6,$allharga,0,0,'R',0);
$pdf->Output();
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>