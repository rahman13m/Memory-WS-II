<?php
include "koneksi.php";
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){
?>
<html>
<title>DATA PASIEN</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
  <div id="wrapper">
    <div id="header">
      <div class="logo">
        <center><img src="1.png" width="100px" height="100px" /></center>
      </div>
      <div class="banner">
      <font size="6">KLINIK SYAHRIAL MEDICA</font><br />
      <font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
        <strong>Phone:</strong>0813-7214-0750
      </div>
    </div>
  <div id="menu">
    <a href="tampildatapasien.php">PASIEN</a>
    <a href="tampildatakaryawan.php">KARYAWAN</a>
    <a href="tampildatapendaftar.php">PENDAFTARAN</a>
    <a href="tampildatapembayar.php">PEMBAYARAN</a>
    <a href="penghasilan.php">PENGHASILAN</a>
    <a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
  </div>
  <div id="content">
    <div class="left-menu">
      <b><u>PASIEN</u></b>
      <ul class="external-link">
            <li><a href="tampildatapasien.php">Tampil Data Pasien</a></li>
            <li><a href="addpasien.php">Tambah Data Pasien</a></li>
            </ul>
    </div>
  <div class="page">
    <h1>Data Pasien Klinik Syahrial Medica</h1>
<form method="post">
<table width="100%" border="0" cellspacing="0" cellpadding="5">
    <tbody>
      <tr>
        <td>
        Pencarian Pasien Berdasarkan : 
        <select name="pilihpasien">
          <option value="pilihan">Pilihan</option>
            <option value="nama">Nama</option>
          <option value="alamat">Alamat</option>
            <option value="tgllahir">Tanggal Lahir</option>
        </select> :
          <input type="text" name = "kode" placeholder="Pencarian" size="30" required>
        <input type="submit" name="search" value="search">
        </td>  
      </tr>
    </tbody>
  </table></form>
<?php 
if(isset($_POST['search'])){
include "cari.php";
}else{
echo("
    <table width='100%' border='0' cellspacing='1' cellpadding='1'>  
      <thead>  
      <th>No</th>  
        <th>No. Medical Record</th>  
        <th>Nama</th>  
        <th>Tanggal Lahir</th>  
        <th>Alamat</th>  
        <th>No. Telp</th>
    <th>Gender</th>
    <th>No Rak</th> 
    <th>Pilihan</th> 
      </thead>  
      <tbody>  
      ");  
      $q = mysql_query("SELECT * FROM pasien ORDER BY no_medicalrecord ASC");  
      $num = 1;

      while ($dat = mysql_fetch_array($q)){  
      echo("                    
      <tr>  
        <td align=center>".$num++."</td>  
        <td align=center>$dat[no_medicalrecord]</td>  
        <td align=center>$dat[nama]</td>  
        <td align=center>$dat[tanggal_lahir]</td>  
    <td align=center>$dat[alamat]</td>  
        <td align=center>$dat[no_telp]</td>
    <td align=center>$dat[gender]</td>
    <td align=center>$dat[no_rak]</td>  
     <td align=center>
      <a href=editdatapasien.php?id=$dat[no_medicalrecord]><button>Edit</button></a>
      <a href=lihatdiagnosalama.php?id=$dat[no_medicalrecord] target='_blank'><button>Diagnosa Lama</button></a>
      <a href=daftar.php?id=$dat[no_medicalrecord]><button>Pendaftaran</button></a>

    </td>  
      </tr>  
      ");  
      }  
      echo("   
      </tbody>  
    </table>              
"); }?>
  </div>
</div>
<div id="footer">&copy; FNF 2016</div>
</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>