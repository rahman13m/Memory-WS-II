<?php
include "koneksi.php";
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='perawat'){

if(isset($_POST['Lunas']))
{
	include 'koneksi.php';
	$id_resep = $_POST['id_resep'];
    $nama = $_POST['nama'];
    $id_karyawan = $_POST['id_karyawan'];
    $no_medicalrecord = $_POST['no_medicalrecord'];
    $harga = $_POST['harga'];

    $update = mysql_query("UPDATE `db_klinik`.`memeriksa` SET `status_pembayaran` = 'sudah dibayar', `total_harga` = '$harga' WHERE `memeriksa`.`id_resep` = '$id_resep'");  
    if($update){ 
        echo("  
            <script>alert('Data resep [ $nama ] sudah dibayar');</script>
            <meta http-equiv=refresh content='0; url=pembayaran.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep' >  

            ");

    }else{  
        echo("  
            <script>alert('ERROR | Data gagal di update')</script>  
            <meta http-equiv=refresh content='0; url=pembayaran.php?idk=$id_karyawan&idp=$no_medicalrecord&idr=$id_resep' >  
        ");   
    }  
}
}elseif(isset($user)&&$level!='perawat'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>