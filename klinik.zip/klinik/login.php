<html>
<head>
<title>Form Login</title>
</head>
<link type="text/css" href="index.css" rel="stylesheet" />
<body>
<center>
	<div id="loginWrapper">
		<div id="loginBox">	
		
			<div id="loginBox-title">
				<h1>Aplikasi Klinik Syahrial Medika</h1>
				<center><img src="1.png"></center>
			<div id="loginBox-body">
			
				<form action="cek_login.php" method="post" name="postform">
				<table border="0" cellpadding="0" cellspacing="0">
				<tbody><tr>
    				<td>Username :</td>
					<td><input name="user" id="username" class="input-teks-login" size="40" placeholder="Username ...." type="text" required="required"></td>
				</tr>
				
				<tr>       
					<td>Password :</td>
					<td><input name="pass" value="" id="password" class="input-teks-login" size="40" placeholder="Password ...." type="password" required="required"></td>
				</tr>
					
				<td></td>
					<td class="submit-button-right">
					<input class="send_btn" type="reset" value="Reset" alt="Reset" title="Reset" />
					<input class="send_btn" type="submit" value="Login" alt="Login" title="Login" /></td>
					
				<tr>
				</tr>
				</table>
				<center><small>Pastikan Username dan Password yang anda masukkan benar</small></center>
				</form>
				
			</div>
		</div>
	</div>
	</center>

</body>
</html>
