<?php  
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='apoteker'){
?>
<html>
<title>PROSES RESEP</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
	<div id="wrapper">
		<div id="header">
			<div class="logo">
				<center><img src="1.png" width="100px" height="100px" /></center>
			</div>
			<div class="banner">
			<font size="6">KLINIK SYAHRIAL MEDICA</font><br />
			<font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
				<strong>Phone:</strong>0813-7214-0750
			</div>
		</div>
	<div id="menu">
		<a href="tampildataobat.php">OBAT</a>
		<a href="tampildatapendaftar.php">RESEP</a>
		<a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
	</div>
	<div id="content">
		<div class="left-menu">
			<b><u>HALAMAN KHUSUS APOTEKER</u></b>
		</div>
	<div class="page">
		<h1>Data Resep Pasien</h1>
<?php
  include "koneksi.php";
    $idk = $_GET['idk'];
    $idp = $_GET['idp'];
    $idr = $_GET['idr'];
	$show = mysql_query("select memeriksa.id_resep, pasien.nama, pasien.gender, karyawan.id_karyawan, karyawan.nama_karyawan from pasien, karyawan, memeriksa where pasien.no_medicalrecord = memeriksa.no_medicalrecord and karyawan.id_karyawan = memeriksa.id_karyawan and pasien.no_medicalrecord = '$idp' and karyawan.id_karyawan = '$idk' and memeriksa.id_resep = '$idr'");
	if(mysql_num_rows($show) == 0)
		{   
		}
		else {
		    $ed = mysql_fetch_assoc($show);   
		}
?>
<form action="fungsiprosesresep.php" method="post">
	<table width="100%" border="0" cellspacing="0" cellpadding="5">
		<tbody>
			<tr>
				<td>Resep No.</td>
				<td>: <input type="text" name="id_resep" value="<?php echo $ed['id_resep']; ?>" size="50" readonly="readonly">
			</tr>
			<tr>
				<td>Nama</td>
				<td>: <input type="text" name="nama" placeholder="Nama" value="<?php echo $ed['nama']; ?>"  size="50" readonly="readonly">
			</tr>
			<tr>
				<td>Gender</td>
				<td>:
					<?php  
					if($ed['gender'] == "laki-laki"){
					echo"<input type='radio' name='gender' value='laki-laki'  size='25' checked> Laki-Laki
					<input type='radio' name='gender' value='perempuan' size='25'disabled > Perempuan";
					}else{
					echo"<input type='radio' name='gender' value='laki-laki' size='25'disabled > Laki-Laki
					<input type='radio' name='gender' value='perempuan' size='25' checked> Perempuan";
					} ?>
				</td>
			</tr>
			<tr>
			<td> Diagnosa Oleh : </td>
				<td> : <input type="text" name="jenis_penyakit" value="<?php echo $ed['nama_karyawan']; ?>"  size="50" readonly="readonly">
			</tr>
			<tbody>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
	<thead>
		<tr>
			<th style="text-align:center">No</th>
			<th style="text-align:center">ID Obat</th>
			<th style="text-align:center">Nama Obat</th>
			<th style="text-align:center">Harga Satuan</th>
			<th style="text-align:center">Jumlah Beli</th>
			<th style="text-align:center">Dosis</th>
			<th style="text-align:center">Total</th>
		</tr>
		</thead>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<?php
include 'koneksi.php';
$id_resep = $ed['id_resep'];
$sql = "select * from mendapatkan where id_resep = '$id_resep'";
$query = mysql_query($sql);
$no =0;
$total =0;
while($data = mysql_fetch_array($query))
{
	$subtotal=$data['harga'];
	$total = $total + $subtotal;
	$no++;
	echo "
	<td><center>".$no."</center></td>
	<td><center>".$data['id_obat']."</center></td>
	<td><center>".$data['namaobat']."</center></td>
	<td><center>".$data['hargasatuan']."</center></td>
	<td><center>".$data['jumlah']."</center></td>
	<td><center>".$data['dosis']."</center></td>
	<td><center>".$data['harga']."</center></td>
	</tr>";
}
echo '</table>'; 
?>
</tbody>
</table>
			<tr>
				<td></td>
				<td><input type="submit" name="Selesai" value="Selesai"></td>  
			</tr>
	</tbody>
	</table>
			
</form>	
	</div>
</div>
<div id="footer">&copy; FNF 2016</div>
</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='apoteker'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>