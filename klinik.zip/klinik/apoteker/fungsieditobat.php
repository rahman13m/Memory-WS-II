<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='apoteker'){

if(isset($_POST['simpan']))
{
	include 'koneksi.php';
	$id_obat = $_POST['id_obat'];
	$nama = $_POST['nama'];
    $harga = $_POST['harga'];  
    $jumlah = $_POST['jumlah'];  
    $kategori_array = $_POST['kategori'];
    foreach($kategori_array as $one_kategori) {
        $source.=$one_kategori.", ";
    }
    $kategori=substr($source,0,-1);
    $perusahaan = $_POST['perusahaan'];

    $update = mysql_query("UPDATE `db_klinik`.`obat` SET `id_obat` = '$id_obat', `nama` = '$nama', `harga` = '$harga', `jumlah` = '$jumlah', `kategori` = '$kategori', `perusahaan` = '$perusahaan' WHERE `obat`.`id_obat` = '$id_obat'");  
    if($update){  
        echo("  
            <script>alert('Data [ $nama ] berhasil di Update')</script>  
            <meta http-equiv=refresh content='0; url=tampildataobat.php' >  
        ");  
    }else{  
        echo("  
            <script>alert('ERROR | Data gagal di update')</script>  
            <meta http-equiv=refresh content='0; url=editobat.php?id='$id_obat' >  
        ");   
    }  
}
}elseif(isset($user)&&$level!='apoteker'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>