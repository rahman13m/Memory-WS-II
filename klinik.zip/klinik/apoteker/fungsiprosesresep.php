<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='apoteker'){

if(isset($_POST['Selesai']))
{
	include 'koneksi.php';
	$id_resep = $_POST['id_resep'];
    $nama = $_POST['nama'];
    $id_karyawan = $_POST['id_karyawan'];
    $no_medicalrecord = $_POST['no_medicalrecord'];

    $update = mysql_query("UPDATE `db_klinik`.`memeriksa` SET `status_pembuatan` = 'sudah dibuat' WHERE `memeriksa`.`id_resep` = '$id_resep'");  
    if($update){  
        echo("  
            <script>alert('Data resep [ $nama ] sudah dibuat')</script>  
            <meta http-equiv=refresh content='0; url=tampildatapendaftar.php' >  
        ");  
    }else{  
        echo("  
            <script>alert('ERROR | Data gagal di update')</script>  
            <meta http-equiv=refresh content='0; url=prosesresep.php?idr=$id_resep&idp=$no_medicalrecord&idk=$id_karyawan' >  
        ");   
    }  
}
}elseif(isset($user)&&$level!='apoteker'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>