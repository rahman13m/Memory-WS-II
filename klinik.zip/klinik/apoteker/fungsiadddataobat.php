<?php
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='apoteker'){
    
if(isset($_POST['submit']))
{
	include "koneksi.php";
	$id_obat = $_POST['id_obat'];
	$nama = $_POST['nama'];
    $harga = $_POST['harga'];  
    $jumlah = $_POST['jumlah'];  
    $kategori_array = $_POST['kategori'];
    foreach($kategori_array as $one_kategori) {
        $source.=$one_kategori.", ";
    }
    $kategori=substr($source,0,-1);
    $perusahaan = $_POST['perusahaan'];
	
	$link = mysql_connect('localhost', 'root', '');
    $db_selected = mysql_select_db('db_klinik');
    $add = mysql_query("INSERT INTO `db_klinik`.`obat` (`id_obat`, `nama`, `jumlah`, `harga`, `kategori`, `perusahaan`) VALUES ('$id_obat', '$nama', '$jumlah', '$harga', '$kategori', '$perusahaan')");
    if($add){  
        include "tampildataobat.php";
		echo("  
            <script>alert('Data [ $nama ] berhasil ditambahkan')</script> 
		");
    }
    else{  
		include "adddataobat.php";
        echo("  
            <script>alert('ERROR | Data gagal di input')</script>  
        ");   
    }
    
}
}elseif(isset($user)&&$level!='apoteker'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>