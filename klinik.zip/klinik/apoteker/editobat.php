<?php  
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='apoteker'){
?>
<html>
<title>EDIT DATA OBAT</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
	<div id="wrapper">
		<div id="header">
			<div class="logo">
				<center><img src="1.png" width="100px" height="100px" /></center>
			</div>
			<div class="banner">
			<font size="6">KLINIK SYAHRIAL MEDICA</font><br />
			<font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
				<strong>Phone:</strong>0813-7214-0750
			</div>
		</div>
	<div id="menu">
		<a href="tampildataobat.php">OBAT</a>
		<a href="tampildatapendaftar.php">RESEP</a>
		<a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
	</div>
	<div id="content">
		<div class="left-menu">
			<b><u>HALAMAN KHUSUS APOTEKER</u></b>
		</div>
	<div class="page">
		<h1>EDIT DATA OBAT</h1>
<?php
  include "koneksi.php";
    $id_obat= $_GET['id'];
	$show = mysql_query("SELECT * FROM obat WHERE id_obat='$id_obat'");
	if(mysql_num_rows($show) == 0)
		{   
		}
		else {
		    $ed = mysql_fetch_assoc($show);   
		}
?>  
<form method="post" action="fungsieditobat.php">
<table width="100%" border="0" cellspacing="0" cellpadding="5">  
  <tbody>
  <tr>
				<td>Id Obat</td>
				<td>: <input type="text" name="id_obat" placeholder="ID OBAT" size="50" readonly="readonly" value="<?php echo $ed['id_obat']; ?>" required> </td>
			</tr>
			<tr>
				<td>Nama Obat</td>
				<td>: <input type="text" name="nama" placeholder="NAMA OBAT" size="50" value="<?php echo $ed['nama']; ?>" required> </td>
			</tr>
			<tr>
				<td>Harga Obat</td>
				<td>: Rp. <input type="text" name="harga" placeholder="HARGA OBAT" size="46" value="<?php echo $ed['harga']; ?>" required> </td>
			</tr>
			<tr>
				<td>Jumlah Obat</td>
				<td>: <input type="text" name="jumlah" placeholder="Masukkan Jumlah Obat yang tersedia.." size="50" value="<?php echo $ed['jumlah']; ?>" required> </td>
			</tr>
			<tr>
				<td>Kategori Obat</td>
				<td> : 
				<input type="checkbox" name="kategori[]" value="dewasa" size="25"> Dewasa
				<input type="checkbox" name="kategori[]" value="anak anak" size="25"> Anak-anak
				<input type="checkbox" name="kategori[]" value="obat dalam" size="25"> Obat Dalam
				<input type="checkbox" name="kategori[]" value="obat luar" size="25"> Obat Luar
				<input type="checkbox" name="kategori[]" value="racikan" size="25"> Racikan
				<input type="checkbox" name="kategori[]" value="non racikan" size="25"> Non Racikan
			  </td>
			</tr>
			<tr>
				<td>Perusahaan</td>
				<td>: <input type="text" name="perusahaan" placeholder="PERUSAHAAN" value="<?php echo $ed['perusahaan']; ?>" size="50"> </td>
			</tr>
			<tr>  
				<td><input type="submit" name="simpan" value="simpan"></td>
				<td></td>
			</tr> 
  </tbody>    
</table>  
</form>
	</div>
</div>
<div id="footer">&copy; FNF 2016</div>
</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='apoteker'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>