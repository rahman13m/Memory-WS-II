<?php  
session_start();
error_reporting("Anda Belum Login!!!");
$user=$_SESSION['username'];
$level=$_SESSION['level'];
$nama_karyawan=$_SESSION['nama'];
include "koneksi.php";
if(isset($user)&&$level=='apoteker'){
?>
<html>
<title>WELCOME TO APLIKASI PENGELOLAAN KLINIK</title>
<link rel="stylesheet" type="text/css" href="buat2.css" />
</head>
<body>
	<div id="wrapper">
		<div id="header">
			<div class="logo">
				<center><img src="1.png" width="100px" height="100px" /></center>
			</div>
			<div class="banner">
			<font size="6">KLINIK SYAHRIAL MEDICA</font><br />
			<font size="4">JL H. Muhammad RT 4 RW 1 No. 11, Batam, Indonesia</font><br />
				<strong>Phone:</strong>0813-7214-0750
			</div>
		</div>
	<div id="menu">
		<a href="tampildataobat.php">OBAT</a>
		<a href="tampildatapendaftar.php">RESEP</a>
		<a href="logout.php">LOG OUT [<?php echo $nama_karyawan." - ".$level; ?>]</a>
	</div>
	<div id="content">
		<div class="left-menu">
			<b><u>HALAMAN KHUSUS APOTEKER</u></b>
		</div>
	<div class="page">
		<p style="border: solid 1px #eceff5; background: #29447E; padding: 15px; margin: 0; text-align: center; line-height: 23px; color: white; font-size: 18px">
			<?php
				echo "<strong>$nama_karyawan</strong> TELAH LOGIN SEBAGAI <strong>$level</strong>";
			?>
		</p>
	</div>
</div>
<div id="footer">&copy; FNF 2016</div>
</div>
</body>
</html>
<?php
}elseif(isset($user)&&$level!='apoteker'){
  echo"<script>alert('Laman ini bukan hak akses anda')</script>
  <meta http-equiv=refresh content='0; url=../index.html' > ";
}else{
  echo"<script>alert('Anda Belum Login')</script>  
    <meta http-equiv=refresh content='0; url=../index.html' > ";
}
?>