-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 27 Jun 2016 pada 13.56
-- Versi Server: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_klinik`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `karyawan`
--

CREATE TABLE IF NOT EXISTS `karyawan` (
  `nama_karyawan` varchar(50) NOT NULL,
  `id_karyawan` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `spesialis` varchar(50) DEFAULT NULL,
  `tarif_konsultasi` int(11) DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `karyawan`
--

INSERT INTO `karyawan` (`nama_karyawan`, `id_karyawan`, `password`, `no_telp`, `spesialis`, `tarif_konsultasi`, `status`, `user`) VALUES
('admin', 'admin', 'admin', '123456', 'bukan dokter', 0, 'aktif', 'perawat'),
('Didin', 'ap001', 'ap001', '081212121212', 'bukan dokter', 0, 'aktif', 'apoteker'),
('Reza', 'dr001', 'dr001', '081111111111', 'Umum', 150000, 'aktif', 'dokter'),
('Dini', 'dr002', 'dr002', '082222222222', 'Gigi', 120000, 'aktif', 'dokter'),
('Diniarti ', 'Dr003', 'dr003', '12121212', 'gigi', 130000, 'aktif', 'dokter'),
('Fatimah', 'pr001', 'pr001', '081234567890', 'bukan dokter', 0, 'aktif', 'perawat');

-- --------------------------------------------------------

--
-- Struktur dari tabel `memeriksa`
--

CREATE TABLE IF NOT EXISTS `memeriksa` (
  `nama_poli` varchar(50) NOT NULL,
  `tanggal` datetime DEFAULT NULL,
  `tindakan` varchar(50) DEFAULT NULL,
  `jenis_penyakit` varchar(50) DEFAULT NULL,
  `jenis_pengobatan` varchar(50) DEFAULT NULL,
  `biaya_tindakan` int(11) DEFAULT NULL,
  `status_pembayaran` varchar(50) DEFAULT NULL,
  `id_karyawan` varchar(50) NOT NULL,
  `no_medicalrecord` varchar(50) NOT NULL,
  `status_diagnosa` varchar(50) DEFAULT NULL,
  `total_harga` int(11) DEFAULT NULL,
  `status_pembuatan` varchar(50) DEFAULT NULL,
  `id_resep` varchar(50) NOT NULL DEFAULT '',
  `keterangan_resep` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `memeriksa`
--

INSERT INTO `memeriksa` (`nama_poli`, `tanggal`, `tindakan`, `jenis_penyakit`, `jenis_pengobatan`, `biaya_tindakan`, `status_pembayaran`, `id_karyawan`, `no_medicalrecord`, `status_diagnosa`, `total_harga`, `status_pembuatan`, `id_resep`, `keterangan_resep`) VALUES
('Umum', '2016-06-16 14:59:59', 'a', 'a', 'a', 110000, 'sudah dibayar', 'dr001', 'ps0001', 'sudah dicek', 31000, 'sudah dibuat', 'RS0001', ''),
('Gigi', '2016-06-21 08:41:50', 'dicabut', 'sakit gigi', 'dicabut', 70000, 'sudah dibayar', 'dr002', 'ps0002', 'sudah dicek', 29000, 'sudah dibuat', 'RS0002', 'asam femanat tiga kali sehari sesudah makan'),
('Umum', '2016-06-24 10:56:54', 'rawat inap', 'demam', 'dikopres', 50000, 'sudah dibayar', 'dr001', 'ps0001', 'sudah dicek', 21000, 'sudah dibuat', 'RS0003', ', asam femanat, 3 kali sehari sesudah makan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mendapatkan`
--

CREATE TABLE IF NOT EXISTS `mendapatkan` (
  `id_resep` varchar(50) DEFAULT NULL,
  `no_medicalrecord` varchar(50) DEFAULT NULL,
  `id_obat` varchar(50) DEFAULT NULL,
  `namaobat` varchar(50) DEFAULT NULL,
  `hargasatuan` int(11) DEFAULT NULL,
  `dosis` varchar(50) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mendapatkan`
--

INSERT INTO `mendapatkan` (`id_resep`, `no_medicalrecord`, `id_obat`, `namaobat`, `hargasatuan`, `dosis`, `jumlah`, `harga`) VALUES
('RS0001', 'ps0001', 'ob0002', 'Paramex', 3500, 'fff', 6, 21000),
('RS0002', 'ps0002', 'ob0004', 'Panadol', 2500, 'berapa aja boleh ', 4, 10000),
('RS0003', 'ps0001', 'ob0001', 'Insana', 2000, '3 Kali Sesudah Makan', 3, 6000),
('RS0003', 'ps0001', 'ob0003', 'Betadine', 15000, 'dioles', 1, 15000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `obat`
--

CREATE TABLE IF NOT EXISTS `obat` (
  `id_obat` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `perusahaan` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `obat`
--

INSERT INTO `obat` (`id_obat`, `nama`, `jumlah`, `harga`, `kategori`, `perusahaan`) VALUES
('ob0001', 'Insana', 17, 2000, 'anak anak, obat dalam, non racikan,', 'PT. Obat Sehat'),
('ob0002', 'Paramex', 20, 3500, 'dewasa, obat dalam, non racikan,', 'PT. Maju Obat'),
('ob0003', 'Betadine', 19, 15000, 'dewasa, anak anak, obat luar, non racikan,', 'PT. Selalu Obat'),
('ob0004', 'Panadol', 20, 2500, 'dewasa, obat dalam, non racikan,', 'PT. Obat Sehat');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien`
--

CREATE TABLE IF NOT EXISTS `pasien` (
  `no_medicalrecord` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `no_rak` varchar(50) NOT NULL,
  `tanggal_lahir` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pasien`
--

INSERT INTO `pasien` (`no_medicalrecord`, `nama`, `alamat`, `no_telp`, `gender`, `no_rak`, `tanggal_lahir`) VALUES
('ps0001', 'Nadia Septa Witirani', 'Baloi Persero', '08998547508', 'perempuan', 'd007', '1996-09-02'),
('ps0002', 'Fitri Rahayu', 'Greenland', '081234567890', 'perempuan', 'A002', '1996-05-02'),
('ps0003', 'Faisal Sadewo', 'Baloi Mas', '088888888888', 'laki-laki', 'R004', '1996-01-01'),
('ps0004', 'Mumut', 'Nagoya', '081212121212', 'laki-laki', 'E004', '1980-06-07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
 ADD PRIMARY KEY (`id_karyawan`);

--
-- Indexes for table `memeriksa`
--
ALTER TABLE `memeriksa`
 ADD PRIMARY KEY (`id_resep`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
 ADD PRIMARY KEY (`no_medicalrecord`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
