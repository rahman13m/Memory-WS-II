-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2017 at 11:40 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_klinik`
--

-- --------------------------------------------------------

--
-- Table structure for table `bpjs`
--

CREATE TABLE IF NOT EXISTS `bpjs` (
  `no_bpjs` varchar(20) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `nik` varchar(20) NOT NULL,
  `golongan` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bpjs`
--

INSERT INTO `bpjs` (`no_bpjs`, `nama`, `alamat`, `tanggal_lahir`, `nik`, `golongan`) VALUES
('0000000000001', 'Nurmala Nispa', 'Anggrek Sari Blok F no 12 Batam Center', '1996-06-20', '2171122006969001', 1),
('0000000000002', 'Putri Karina', 'Citra Batam blok D no 253', '1996-04-13', '2171123049690002', 1);

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE IF NOT EXISTS `karyawan` (
  `nama_karyawan` varchar(50) NOT NULL,
  `id_karyawan` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `spesialis` varchar(50) DEFAULT NULL,
  `tarif_konsultasi` int(11) DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`nama_karyawan`, `id_karyawan`, `password`, `no_telp`, `spesialis`, `tarif_konsultasi`, `status`, `user`) VALUES
('Welly', 'admin', 'admin', '123456', 'Bukan Dokter', 0, 'Aktif', 'Admin'),
('Shizuka', 'ap001', 'ap001', '085321233432', 'Bukan Dokter', 9500, 'Aktif', 'Apoteker'),
('Rahman', 'dr001', 'dr001', '081111111111', 'Umum', 150000, 'Aktif', 'Dokter'),
('Zaskia', 'dr005', 'dr005', '081993732012', 'Gigi', 100000, 'Aktif', 'Dokter'),
('Intan', 'pr001', 'pr001', '081298382165', 'Bukan Dokter', 0, 'Aktif', 'Perawat');

-- --------------------------------------------------------

--
-- Table structure for table `memeriksa`
--

CREATE TABLE IF NOT EXISTS `memeriksa` (
  `nama_poli` varchar(50) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `tindakan` varchar(50) DEFAULT NULL,
  `jenis_penyakit` varchar(50) DEFAULT NULL,
  `jenis_pengobatan` varchar(50) DEFAULT NULL,
  `biaya_tindakan` int(11) DEFAULT NULL,
  `status_pembayaran` varchar(50) DEFAULT NULL,
  `id_karyawan` varchar(50) NOT NULL,
  `no_medicalrecord` varchar(50) NOT NULL,
  `status_diagnosa` varchar(50) DEFAULT NULL,
  `total_harga` int(11) DEFAULT NULL,
  `status_pembuatan` varchar(50) DEFAULT NULL,
  `id_resep` varchar(50) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `memeriksa`
--

INSERT INTO `memeriksa` (`nama_poli`, `tanggal`, `tindakan`, `jenis_penyakit`, `jenis_pengobatan`, `biaya_tindakan`, `status_pembayaran`, `id_karyawan`, `no_medicalrecord`, `status_diagnosa`, `total_harga`, `status_pembuatan`, `id_resep`) VALUES
('Poli Umum', '2017-01-05', 'Diberi obat', 'Diare', 'Diberi obat pereda diare', 45000, 'Sudah dibayar', 'dr001', 'ps0002', 'Sudah dicek', 55000, 'Belum dibuat', 'Rs0001   '),
('Poli Gigi', '2017-03-05', 'Ditambal', 'Gigi Berlubang', 'Diberi alkohol pada bagian gigi yang berlubang', 44000, 'Sudah dibayar', 'dr001', 'ps0001', 'Sudah dicek', 50000, 'Sudah dibuat', 'Rs0002'),
('Poli Ibu dan Anak', '2017-05-03', 'Belum ada tindakan', 'Cek Kehamilan', 'Belum ada pengobatan', 0, 'Belum dibayar', 'dr001', 'ps0003', 'Belum dicek', 0, 'Belum dibuat', 'Rs0003'),
('umum', '2017-05-09', 'di ronsen', 'paru-paru', 'kemoterapi', 1000000, 'Belum dibayar', 'dr005', 'ps0002', 'Sudah dicek', 2000000, 'Sudah dibuat', 'Rs0004 '),
('gigi', '2017-05-29', 'oke', 'jantung', 'oke', 100, 'Belum dibayar', 'dr005', 'ps0003', 'Sudah dicek', 1000, 'Sudah dibuat', 'Rs0005'),
('gigi', '2017-06-21', 'oo', 'g', 'laaa', 200, NULL, 'dr005', 'ps0001', NULL, 100, 'Tidak Butuh resep', 'Rs0006');

-- --------------------------------------------------------

--
-- Table structure for table `mendapatkan`
--

CREATE TABLE IF NOT EXISTS `mendapatkan` (
  `id_resep` varchar(50) DEFAULT NULL,
  `no_medicalrecord` varchar(50) DEFAULT NULL,
  `namaobat` varchar(100) DEFAULT NULL,
  `dosis` varchar(50) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mendapatkan`
--

INSERT INTO `mendapatkan` (`id_resep`, `no_medicalrecord`, `namaobat`, `dosis`, `harga`) VALUES
('Rs0001', 'ps0002', 'Betadine', '3x1 hari', 7000),
('Rs0002', 'ps0002', 'OGI', '2x1 hari', 5000),
('Rs0003', 'ps0003', 'betadine, antiseptik, ampisilin', '2x1 hari', 60000),
('Rs0004', 'ps0003', 'CTM', '500ml', 500);

-- --------------------------------------------------------

--
-- Table structure for table `obat`
--

CREATE TABLE IF NOT EXISTS `obat` (
  `id_obat` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `perusahaan` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `obat`
--

INSERT INTO `obat` (`id_obat`, `nama`, `jumlah`, `harga`, `kategori`, `perusahaan`) VALUES
('ob0001', 'Paramex (Tablet)', 220, 500, 'Dewasa', 'Konimex Pharmaceutical Laboratories'),
('ob0002', 'Combantrin (Tablet)', 300, 5000, 'Anak-Anak', 'COMBANTRIN(R)'),
('ob0003', 'Sangobion (Kapsul)', 500, 12000, 'Dewasa', 'PT. Merck Tbk.'),
('ob0004', 'Sakatonik ABC', 480, 10500, 'Anak-Anak', 'PT. Saka Farma Laboratories'),
('ob0005', 'Sakatonik Liver (Kapsul)', 400, 5000, 'Dewasa', 'PT. Saka Farma Laboratories'),
('ob0006', 'Sakatonik Liver (Tablet)', 200, 4200, 'Dewasa', 'PT. Saka Farma Laboratories'),
('ob0007', 'Sakatonik Liver (Sirup)', 700, 32100, 'Dewasa', 'PT. Saka Farma Laboratories'),
('ob0008', 'FreshCare Sport', 200, 15000, 'Anak-Anak, Dewasa', 'PT. Ultra Sakti');

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--

CREATE TABLE IF NOT EXISTS `pasien` (
  `no_medicalrecord` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `tanggal_lahir` varchar(50) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pasien`
--

INSERT INTO `pasien` (`no_medicalrecord`, `nama`, `alamat`, `no_telp`, `gender`, `tanggal_lahir`, `status`) VALUES
('ps0001', 'Nurmala Nisfa', 'Anggrek Sari Blok F no 12 Batam Center', '081270707934', 'Perempuan', '1996-06-20', 'Sudah Diperiksa'),
('ps0002', 'Farina', 'Sungai Harapan', '081270774917', 'Perempuan', '1996-09-28', 'Proses Pendaftaran'),
('ps0003', 'Putri Karina', 'Citra Batam blok D no 253', '081276765521', 'Perempuan', '1996-04-13', 'Sudah Diperiksa'),
('ps0004', 'Suneo', 'Jepang', '08779231212', 'Laki-laki', '1993-02-02', 'Dalam Pemeriksaan'),
('ps0005', 'akbar', 'Tiban', '08176773181', 'Laki-laki', '2017-05-02', 'Dalam Pemeriksaan');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE IF NOT EXISTS `pembayaran` (
  `no_struk` varchar(15) NOT NULL,
  `no_medicalrecord` varchar(15) NOT NULL,
  `nama_pasien` varchar(30) NOT NULL,
  `alamat` varchar(40) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `tanggal_in` date NOT NULL,
  `tanggal_out` date NOT NULL,
  `tagihan` varchar(15) NOT NULL,
  `jenis_pembayaran` varchar(15) NOT NULL,
  `total` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`no_struk`, `no_medicalrecord`, `nama_pasien`, `alamat`, `no_telp`, `tanggal_in`, `tanggal_out`, `tagihan`, `jenis_pembayaran`, `total`) VALUES
('s000001', 'ps0002', 'Farina', 'Sungai Harapan', '081270774917', '2017-03-05', '2017-03-09', '77000', 'BPJS', '50000'),
('s000002', 'ps0001', 'Nurmala Nispa', 'Anggrek Sari Blok F no 12 Batam Center', '0812707079341', '2016-04-06', '2016-04-11', '355000', 'BPJS', '340000'),
('s000003', 'ps0003', 'Putri Karina', 'Citra Batam blok D no 253', '081276765521', '2017-03-01', '2017-03-01', '35000', 'Cash', '35000');

-- --------------------------------------------------------

--
-- Table structure for table `pendaftaran`
--

CREATE TABLE IF NOT EXISTS `pendaftaran` (
  `id_karyawan` varchar(15) NOT NULL,
  `nama_karyawan` varchar(30) NOT NULL,
  `spesialis` varchar(15) NOT NULL,
  `nama_pasien` varchar(30) NOT NULL,
  `no_medicalrecord` varchar(15) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pendaftaran`
--

INSERT INTO `pendaftaran` (`id_karyawan`, `nama_karyawan`, `spesialis`, `nama_pasien`, `no_medicalrecord`, `tanggal`) VALUES
('dr005', 'Zaskia', 'Gigi', 'Nurmala Nisfa', 'ps0001', '2017-05-29'),
('dr001', 'Rahman', 'Umum', 'Farina', 'ps0002', '2017-03-05'),
('dr005', 'Zaskia', 'Gigi', 'Putri Karina', 'ps0003', '2017-05-11'),
('dr001', 'Rahman', 'Umum', 'Suneo', 'ps0004', '2017-05-10');

-- --------------------------------------------------------

--
-- Table structure for table `penggajian`
--

CREATE TABLE IF NOT EXISTS `penggajian` (
  `id_karyawan` varchar(30) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jabatan` varchar(15) NOT NULL,
  `jumlah_jam` varchar(5) NOT NULL,
  `upah` varchar(15) NOT NULL,
  `overtime` varchar(15) NOT NULL,
  `upah_overtime` varchar(15) NOT NULL,
  `potongan` varchar(15) NOT NULL,
  `total_gaji` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penggajian`
--

INSERT INTO `penggajian` (`id_karyawan`, `nama`, `jabatan`, `jumlah_jam`, `upah`, `overtime`, `upah_overtime`, `potongan`, `total_gaji`) VALUES
('admin', 'admin', 'Apoteker', '300', '20000', '480', '15000', '132000', '13068000'),
('pr001', 'Shizuka', 'Perawat', '300', '15000', '30', '10000', '480000', '4320000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bpjs`
--
ALTER TABLE `bpjs`
 ADD PRIMARY KEY (`no_bpjs`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
 ADD PRIMARY KEY (`id_karyawan`);

--
-- Indexes for table `memeriksa`
--
ALTER TABLE `memeriksa`
 ADD PRIMARY KEY (`id_resep`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
 ADD PRIMARY KEY (`no_medicalrecord`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
 ADD PRIMARY KEY (`no_struk`);

--
-- Indexes for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
 ADD PRIMARY KEY (`no_medicalrecord`);

--
-- Indexes for table `penggajian`
--
ALTER TABLE `penggajian`
 ADD PRIMARY KEY (`id_karyawan`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
