<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class c_tambahmemeriksa extends CI_Controller {
function __construct(){
parent::__construct();
$this->load->model("m_memeriksa");
}

	public function index()
	{
		$this->load->view('dokter/tambahmemeriksa');
	}

public function showMemeriksa()
{

$data['listMemeriksa'] = $this->m_memeriksa->getAllMemeriksa();
$this->load->view('dokter/memeriksa', $data);
}

public function addMemeriksa()
{
$this->load->view('tambahmemeriksa');
}
public function addmemeriksaDb()
{
$data = array(
'no_medicalrecord' => $this->input->post('no_medicalrecord'),
'id_resep' => $this->input->post('id_resep'),
'id_karyawan' => $this->input->post('id_karyawan'),
'nama_poli' => $this->input->post('nama_poli'),
'jenis_penyakit' => $this->input->post('jenis_penyakit'),
'tindakan' => $this->input->post('tindakan'),
'jenis_pengobatan' => $this->input->post('jenis_pengobatan'),
'status_pembuatan' => $this->input->post('status_pembuatan'),
'biaya_tindakan' => $this->input->post('biaya_tindakan'),
'tanggal' => $this->input->post('tanggal'),
'total_harga' => $this->input->post('total_harga')
);
$this->m_memeriksa->addMemeriksaDb($data);
redirect('/index.php/dokter/c_memeriksa');

}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */