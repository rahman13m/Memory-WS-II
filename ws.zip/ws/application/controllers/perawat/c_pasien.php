<?php
session_start();
class c_pasien extends CI_Controller {
function __construct(){
parent::__construct();
$this->load->model("m_pasien");
if ($this->session->userdata('id_karyawan')=="") {
			redirect('index.php/login');
}
$this->load->helper('text');
}

public function index()
{
$data['id_karyawan'] = $this->session->userdata('id_karyawan');
$data['password'] = $this->session->userdata('password');
$data['listPasien'] = $this->m_pasien->getAllPasien();
$this->load->view('perawat/pasien', $data);
}

public function addPasien()
{
$this->load->view('tambahpasien');
}
public function addpasienDb()
{
$data = array(
'no_medicalrecord' => $this->input->post('no_medicalrecord'),
'nama' => $this->input->post('nama'),
'alamat' => $this->input->post('alamat'),
'no_telp' => $this->input->post('no_telp'),
'gender' => $this->input->post('gender'),
'tanggal_lahir' => $this->input->post('tanggal_lahir'),
'status' => $this->input->post('status')
);
$this->m_pasien->addPasien($data);
redirect('c_tambahpasien');
}
public function updatePasien($no_medicalrecord)
{

$data['pasien'] = $this->m_pasien->getPasien($no_medicalrecord);
$this->load->view('perawat/editpasien', $data);
}

public function updatePasienDb()
{
$data = array(
'no_medicalrecord' => $this->input->post('no_medicalrecord'),
'nama' => $this->input->post('nama'),
'alamat' => $this->input->post('alamat'),
'no_telp' => $this->input->post('no_telp'),
'gender' => $this->input->post('gender'),
'tanggal_lahir' => $this->input->post('tanggal_lahir'),
'status' => $this->input->post('status')
);
$condition['no_medicalrecord'] = $this->input->post('no_medicalrecord'); 
$this->m_pasien->updatePasien($data, $condition);
redirect('/index.php/perawat/c_pasien');
}

public function detailPasien($no_medicalrecord)
{
$data['detailpasien'] = $this->m_pasien->getPasien($no_medicalrecord);
$this->load->view('perawat/detailPasien', $data);
}
public function detailPasienDb()
{
$data = array(
'no_medicalrecord' => $this->input->post('no_medicalrecord'),
'nama' => $this->input->post('nama'),
'alamat' => $this->input->post('alamat'),
'no_telp' => $this->input->post('no_telp'),
'gender' => $this->input->post('gender'),
'tanggal_lahir' => $this->input->post('tanggal_lahir'),
'status' => $this->input->post('status'),
);
$condition['no_medicalrecord'] = $this->input->post('no_medicalrecord'); 
$this->m_pasien->updatePasien($data, $condition);
redirect('/index.php/perawat/c_pasien');
}

public function deletePasienDb($no_medicalrecord)
{
$del = $this->m_pasien->deletePasien($no_medicalrecord); 
if ($del){
echo ("<script>alert('Data [$nama] berhasil dihapus')</script>");
redirect('/index.php/perawat/c_pasien');
}
}

function search_keyword()
    {
        $keyword = $this->input->post('keyword');
        $data['listPasien'] = $this->m_pasien->search($keyword);
        $this->load->view('perawat/pasien',$data);
    }

}