<?php
session_start();
class c_pembayaran extends CI_Controller {
function __construct(){
parent::__construct();
$this->load->model("m_pembayaran");
if ($this->session->userdata('id_karyawan')=="") {
			redirect('index.php/login');
}
$this->load->helper('text');
}


public function index()
{
$data['id_karyawan'] = $this->session->userdata('id_karyawan');
$data['password'] = $this->session->userdata('password');
$data['listPembayaran'] = $this->m_pembayaran->getAllPembayaran();
$this->load->view('perawat/pembayaran', $data);
}

public function addPembayaran()
{
$this->load->view('tambahpembayaran');
}
public function addpembayaranDb()
{
$data = array(
'no_struk' => $this->input->post('no_struk'),
'no_medicalrecord' => $this->input->post('no_medicalrecord'),
'nama_pasien' => $this->input->post('nama_pasien'),
'alamat' => $this->input->post('alamat'),
'no_telp' => $this->input->post('no_telp'),
'tanggal_in' => $this->input->post('tanggal_in'),
'tanggal_out' => $this->input->post('tanggal_out'),
'tagihan' => $this->input->post('tagihan'),
'jenis_pembayaran' => $this->input->post('jenis_pembayaran'),
'total' => $this->input->post('total')

);
$this->m_pembayaran->addPembayaran($data);
redirect('/index.php/perawat/c_pembayaran');
}


public function updatePembayaran($no_struk)
{

$data['pembayaran'] = $this->m_pembayaran->getPembayaran($no_struk);
$this->load->view('perawat/editpembayaran', $data);
}

public function updatePembayaranDb()
{
$data = array(
'no_struk' => $this->input->post('no_struk'),
'no_medicalrecord' => $this->input->post('no_medicalrecord'),
'nama_pasien' => $this->input->post('nama_pasien'),
'alamat' => $this->input->post('alamat'),
'no_telp' => $this->input->post('no_telp'),
'tanggal_in' => $this->input->post('tanggal_in'),
'tanggal_out' => $this->input->post('tanggal_out'),
'tagihan' => $this->input->post('tagihan'),
'jenis_pembayaran' => $this->input->post('jenis_pembayaran'),
'total' => $this->input->post('total')

);
$condition['no_struk'] = $this->input->post('no_struk'); 
$this->m_pembayaran->updatePembayaran($data, $condition);
redirect('/index.php/perawat/c_pembayaran');
}


public function detailPembayaran($no_struk)
{

$data['detailpembayaran'] = $this->m_pembayaran->getPembayaran($no_struk);
$this->load->view('perawat/detailPembayaran', $data);
}

public function detailPembayaranDb()
{
$data = array(
'no_struk' => $this->input->post('no_struk'),
'no_medicalrecord' => $this->input->post('no_medicalrecord'),
'nama_pasien' => $this->input->post('nama_pasien'),
'alamat' => $this->input->post('alamat'),
'no_telp' => $this->input->post('no_telp'),
'tanggal_in' => $this->input->post('tanggal_in'),
'tanggal_out' => $this->input->post('tanggal_out'),
'tagihan' => $this->input->post('tagihan'),
'jenis_pembayaran' => $this->input->post('jenis_pembayaran'),
'total' => $this->input->post('total')

);
$condition['no_struk'] = $this->input->post('no_struk'); 
$this->m_pembayaran->updatePembayaran($data, $condition);
redirect('/index.php/perawat/c_pembayaran');
}

public function deletePembayaranDb($no_struk)
{
$this->session->set_flashdata('msg', '<div class="alert alert-info">
Data berhasil dihapus !</div>');
$this->m_pembayaran->deletePembayaran($no_struk); 
redirect('/index.php/perawat/c_pembayaran');

}

function search_keyword()
    {
        $keyword = $this->input->post('keyword');
        $data['listPembayaran'] = $this->m_pembayaran->search($keyword);
        $this->load->view('perawat/pembayaran',$data);
    }
	
	function search_penghasilan()
    {
        $keyword = $this->input->post('keyword');
        $data['listPenghasilan'] = $this->m_pembayaran->tampil($keyword);
        $this->load->view('perawat/penghasilan',$data);
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */