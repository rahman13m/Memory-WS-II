<?php
session_start();
class c_bpjs extends CI_Controller {

function __construct(){
parent::__construct();
$this->load->model("m_bpjs");
if ($this->session->userdata('id_karyawan')=="") {
			redirect('index.php/login');
			echo"<script>alert('Laman ini bukan hak akses anda')</script>";
		
		
}
$this->load->helper('text');
}
public function index()
{
$data['id_karyawan'] = $this->session->userdata('id_karyawan');
$data['password'] = $this->session->userdata('password');
$data['listBpjs'] = $this->m_bpjs->getAllBpjs();
$this->load->view('perawat/bpjs', $data);
}

public function addBpjs()
{
$this->load->view('tambahbpjs');
}
public function addbpjsDb()
{
$data = array(
'no_bpjs' => $this->input->post('no_bpjs'),
'nama' => $this->input->post('nama'),
'alamat' => $this->input->post('alamat'),
'tanggal_lahir' => $this->input->post('tanggal_lahir'),
'nik' => $this->input->post('nik'),
'golongan' => $this->input->post('golongan')

);
$this->m_pasien->addBpjs($data);
redirect('c_tambahbpjs');
}
public function updateBpjs($no_bpjs)
{

$data['bpjs'] = $this->m_bpjs->getBpjs($no_bpjs);
$this->load->view('perawat/editbpjs', $data);
}
public function updateBpjsDb()
{
$data = array(
'no_bpjs' => $this->input->post('no_bpjs'),
'nama' => $this->input->post('nama'),
'alamat' => $this->input->post('alamat'),
'tanggal_lahir' => $this->input->post('tanggal_lahir'),
'nik' => $this->input->post('nik'),
'golongan' => $this->input->post('golongan')
);
$condition['no_bpjs'] = $this->input->post('no_bpjs'); 
$this->m_bpjs->updateBpjs($data, $condition);
redirect('/index.php/perawat/c_bpjs');
}

public function detailBpjs($no_bpjs)
{

$data['detailbpjs'] = $this->m_bpjs->getBpjs($no_bpjs);
$this->load->view('perawat/detailBpjs', $data);
}
public function detailBpjsDb()
{
$data = array(
'no_bpjs' => $this->input->post('no_bpjs'),
'nama' => $this->input->post('nama'),
'alamat' => $this->input->post('alamat'),
'tanggal_lahir' => $this->input->post('tanggal_lahir'),
'nik' => $this->input->post('nik'),
'golongan' => $this->input->post('golongan')
);
$condition['no_bpjs'] = $this->input->post('no_bpjs'); 
$this->m_bpjs->updateBpjs($data, $condition);
redirect('/index.php/perawat/c_bpjs');
}

public function deleteBpjsDb($no_bpjs)
{

$this->m_bpjs->deletePasien($no_bpjs); 
redirect('/index.php/perawat/c_bpjs');

}

function search_keyword()
    {
        $keyword = $this->input->post('keyword');
        $data['listBpjs'] = $this->m_bpjs->search($keyword);
        $this->load->view('perawat/bpjs',$data);
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */