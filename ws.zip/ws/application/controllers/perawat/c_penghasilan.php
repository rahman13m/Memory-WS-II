<?php
session_start();
class c_Penghasilan extends CI_Controller {

function __construct(){
parent::__construct();
$this->load->model("m_pembayaran");
if ($this->session->userdata('id_karyawan')=="") {
			redirect('index.php/login');
}
$this->load->helper('text');
}
	public function index()
{
$data['id_karyawan'] = $this->session->userdata('id_karyawan');
$data['password'] = $this->session->userdata('password');
$data['listPenghasilan'] = $this->m_pembayaran->getPenghasilan();
$this->load->view('perawat/penghasilan', $data);
}
	
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */