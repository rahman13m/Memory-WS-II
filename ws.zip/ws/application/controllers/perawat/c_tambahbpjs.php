<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class c_tambahbpjs extends CI_Controller {
function __construct(){
parent::__construct();
$this->load->model("m_bpjs");
}

	public function index()
	{
		$this->load->view('perawat/tambahbpjs');
	}

public function showBpjs()
{

$data['listBpjs'] = $this->m_bpjs->getAllBpjs();
$this->load->view('perawat/bpjs', $data);
}

public function addBpjs()
{
$this->load->view('tambahbpjs');
}
public function addbpjsDb()
{
$data = array(
'no_bpjs' => $this->input->post('no_bpjs'),
'nama' => $this->input->post('nama'),
'alamat' => $this->input->post('alamat'),
'tanggal_lahir' => $this->input->post('tanggal_lahir'),
'nik' => $this->input->post('nik'),
'golongan' => $this->input->post('golongan')

);
$this->m_bpjs->addBpjs($data);
redirect('/index.php/perawat/c_bpjs');

}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */