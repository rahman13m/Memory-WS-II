<?php
session_start();
class c_pendaftaran extends CI_Controller {
function __construct(){
parent::__construct();
$this->load->model("m_pendaftaran");
if ($this->session->userdata('id_karyawan')=="") {
			redirect('index.php/login');
}
$this->load->helper('text');
}
public function index()
{
$data['id_karyawan'] = $this->session->userdata('id_karyawan');
$data['password'] = $this->session->userdata('password');
$data['listPendaftaran'] = $this->m_pendaftaran->getAllPendaftaran();
$this->load->view('perawat/Pendaftaran', $data);
}

public function updatePendaftaran($no_medicalrecord)
{
$data['pendaftaran'] = $this->m_pendaftaran->getPendaftaran($no_medicalrecord);
$this->load->view('perawat/tambahpendaftaran', $data);
}

public function addpendaftaranDb()
{
$data = array(
'id_karyawan' => $this->input->post('id_karyawan'),
'nama_karyawan' => $this->input->post('nama_karyawan'),
'spesialis' => $this->input->post('spesialis'),
'nama_pasien' => $this->input->post('nama_pasien'),
'no_medicalrecord' => $this->input->post('no_medicalrecord'),
'tanggal' => $this->input->post('tanggal')
);


$this->m_pendaftaran->addPendaftaran($data);
redirect('/index.php/perawat/c_pendaftaran');
}

public function deletePendaftaranDb($no_medicalrecord)
{
$this->m_pendaftaran->deletePendaftaran($no_medicalrecord);
 
$this->session->set_flashdata('msg', '<div class="alert alert-info">
Data berhasil dihapus !</div>');
redirect('/index.php/perawat/c_pendaftaran');	

}

public function detailPendaftaran($no_medicalrecord)
{

$data['detailpendaftaran'] = $this->m_pendaftaran->getdetailPendaftaran($no_medicalrecord);
$this->load->view('perawat/detailPendaftaran', $data);
}
public function detailPendaftaranDb()
{
$data = array(
'id_karyawan' => $this->input->post('id_karyawan'),
'nama_karyawan' => $this->input->post('nama_karyawan'),
'spesialis' => $this->input->post('spesialis'),
'nama_pasien' => $this->input->post('nama_pasien'),
'no_medicalrecord' => $this->input->post('no_medicalrecord'),
'tanggal' => $this->input->post('tanggal')
);
$condition['no_medicalrecord'] = $this->input->post('no_medicalrecord'); 
$this->m_bpjs->updateBpjs($data, $condition);
redirect('/index.php/perawat/c_pendaftaran');
}

function search_keyword()
    {
        $keyword = $this->input->post('keyword');
        $data['listPendaftaran'] = $this->m_pendaftaran->search($keyword);
        $this->load->view('perawat/pendaftaran',$data);
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */