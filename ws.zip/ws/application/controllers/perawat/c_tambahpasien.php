<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class c_tambahpasien extends CI_Controller {
function __construct(){
parent::__construct();
$this->load->model("m_pasien");
}

	public function index()
	{
		$this->load->view('perawat/tambahpasien');
	}

public function showPasien()
{

$data['listPasien'] = $this->m_pasien->getAllPasien();
$this->load->view('perawat/pasien', $data);
}

public function addPasien()
{
$this->load->view('tambahpasien');
}
public function addpasienDb()
{
$data = array(
'no_medicalrecord' => $this->input->post('no_medicalrecord'),
'nama' => $this->input->post('nama'),
'alamat' => $this->input->post('alamat'),
'no_telp' => $this->input->post('no_telp'),
'gender' => $this->input->post('gender'),
'tanggal_lahir' => $this->input->post('tanggal_lahir'),
'status' => $this->input->post('status')
);
$this->m_pasien->addPasien($data);
redirect('/index.php/perawat/c_pasien');

}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */