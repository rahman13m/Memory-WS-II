<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class rujukan extends CI_Controller {
	public function index()
	{
		
		ob_start();
		$content = $this->load->view('rujukan');
		$content = ob_get_clean();		
		$this->load->library('html2pdf');
		try
		{
			$html2pdf = new HTML2PDF('M', 'A4', 'fr');
			$html2pdf->pdf->SetDisplayMode('fullpage');
			$html2pdf->writeHTML($content, isset($_GET['vuehtml']));
			$html2pdf->Output('Penghasilan.pdf');
		}
		catch(HTML2PDF_exception $e) {
			echo $e;
			exit;
		}
		
	}
	
	public function cetak()
	{
		$this->load->model('m_rujukan');
		$data['rujukan'] = $this->m_rujukan->tampil();
		$this->load->view('data',$data);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */