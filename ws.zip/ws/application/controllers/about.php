<?php 

class about extends CI_Controller{

	function index(){
		$this->load->view('about');
	}

}