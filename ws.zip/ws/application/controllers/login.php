<?php
session_start();
class login extends CI_Controller {

	function __construct(){
		parent::__construct();		
		$this->load->model('m_login');

	}
	function index() {
		$this->load->view('login');
	}

		public function aksi_login() {
		$data = array('id_karyawan' => $this->input->post('id_karyawan', TRUE),
						'password' => $this->input->post('password', TRUE)
			);
		$this->load->model('m_login'); // load model_user
		$hasil = $this->m_login->cek_user($data);
		if ($hasil->num_rows() > 0) {
			foreach ($hasil->result() as $sess) {
				$sess_data['logged_in'] = 'Sudah Loggin';
				$sess_data['id_karyawan'] = $sess->id_karyawan;
				$sess_data['nama_karyawan'] = $sess->nama_karyawan;
				$sess_data['user'] = $sess->user;
				$this->session->set_userdata($sess_data);
			}
			if ($this->session->userdata('user')=='Admin') {
				redirect('index.php/perawat/c_homeP');
			}
			elseif ($this->session->userdata('user')=='Perawat') {
				redirect('index.php/perawat/c_homeP');
			}		
		}
		else {
			echo "<script>alert('Gagal login: Cek username, password!');history.go(-1);</script>";
		}
	}
function logout() {
		$this->session->unset_userdata('id_karyawan');
		$this->session->unset_userdata('user');
		$this->session->unset_userdata('nama_karyawan');
		session_destroy();
		redirect('index.php/login');
	}
	
}

?>