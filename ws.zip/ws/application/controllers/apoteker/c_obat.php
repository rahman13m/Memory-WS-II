<?php
session_start();

class c_obat extends CI_Controller {
function __construct(){
parent::__construct();
$this->load->model("m_obat");
if ($this->session->userdata('id_karyawan')=="") {
			redirect('index.php/login');
}
$this->load->helper('text');
}
public function index()
{
$data['id_karyawan'] = $this->session->userdata('id_karyawan');
$data['password'] = $this->session->userdata('password');
$data['listObat'] = $this->m_obat->getAllObat();
$this->load->view('apoteker/obat', $data);
}

public function addObat()
{
$this->load->view('tambahobat');
}
public function addobatDb()
{
$data = array(
'id_obat' => $this->input->post('id_obat'),
'nama' => $this->input->post('nama'),
'jumlah' => $this->input->post('jumlah'),
'harga' => $this->input->post('harga'),
'kategori' => $this->input->post('kategori'),
'perusahaan' => $this->input->post('perusahaan'),
);
$this->m_obat->addobat($data);
redirect('c_tambahobat');
}
public function updateObat($id_obat)
{
$data['obat'] = $this->m_obat->getObat($id_obat);
$this->load->view('apoteker/editobat', $data);
}

public function updateObatDb()
{
$data = array(
'id_obat' => $this->input->post('id_obat'),
'nama' => $this->input->post('nama'),
'jumlah' => $this->input->post('jumlah'),
'harga' => $this->input->post('harga'),
'kategori' => $this->input->post('kategori'),
'perusahaan' => $this->input->post('perusahaan'),
);
$condition['id_obat'] = $this->input->post('id_obat'); 
$this->m_obat->updateObat($data, $condition);
redirect('/index.php/apoteker/c_obat');
}

public function detailObat($id_obat)
{
$data['detailobat'] = $this->m_obat->getObat($id_obat);
$this->load->view('apoteker/detailObat', $data);
}

public function detailObatDb()
{
$data = array(
'id_obat' => $this->input->post('id_obat'),
'nama' => $this->input->post('nama'),
'jumlah' => $this->input->post('jumlah'),
'harga' => $this->input->post('harga'),
'kategori' => $this->input->post('kategori'),
'perusahaan' => $this->input->post('perusahaan')
);
$condition['id_obat'] = $this->input->post('id_obat'); 
$this->m_obat->updateObat($data, $condition);
redirect('/index.php/apoteker/c_obat');
}

public function deleteObatDb($id_obat)
{
$this->session->set_flashdata('msg', '<div class="alert alert-info">
Data berhasil dihapus !</div>');
$this->m_obat->deleteObat($id_obat); 
redirect('/index.php/apoteker/c_obat');
}

function search_keyword()
    {
        $keyword = $this->input->post('keyword');
        $data['listObat'] = $this->m_obat->search($keyword);
        $this->load->view('apoteker/obat',$data);
    }

}