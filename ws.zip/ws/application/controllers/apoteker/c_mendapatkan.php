<?php
session_start();
class c_mendapatkan extends CI_Controller {
function __construct(){
parent::__construct();
$this->load->model("m_mendapatkan");
if ($this->session->userdata('id_karyawan')=="") {
			redirect('index.php/login');
}
$this->load->helper('text');
}
public function index()
{
$data['id_karyawan'] = $this->session->userdata('id_karyawan');
$data['password'] = $this->session->userdata('password');
$data['listMendapatkan'] = $this->m_mendapatkan->getAllMendapatkan();
$this->load->view('apoteker/mendapatkan', $data);
}

public function detailMendapatkan($id_resep)
{
$data['detailmendapatkan'] = $this->m_mendapatkan->getMendapatkan($id_resep);
$this->load->view('apoteker/detailMendapatkan', $data);
}
public function detailMendapatkanDb()
{
$data = array(
'id_resep' => $this->input->post('id_resep'),
'no_medicalrecord' => $this->input->post('no_medicalrecord'),
'id_obat' => $this->input->post('id_obat'),
'namaobat' => $this->input->post('namaobat'),
'hargasatuan' => $this->input->post('hargasatuan'),
'dosis' => $this->input->post('dosis'),
'jumlah' => $this->input->post('jumlah'),
'harga' => $this->input->post('harga'),
);
$condition['id_resep'] = $this->input->post('id_resep'); 
$this->m_mendapatkan->updateMendapatkan($data, $condition);
redirect('/index.php/apoteker/c_mendapatkan');
}

function search_keyword()
    {
        $keyword = $this->input->post('keyword');
        $data['listMendapatkan'] = $this->m_mendapatkan->search($keyword);
        $this->load->view('apoteker/mendapatkan',$data);
    }

}