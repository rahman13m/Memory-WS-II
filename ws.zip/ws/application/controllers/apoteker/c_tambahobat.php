<?php
session_start();
class c_tambahobat extends CI_Controller {
function __construct(){
parent::__construct();
$this->load->model("m_obat");
if ($this->session->userdata('id_karyawan')=="") {
			redirect('index.php/login');
}
$this->load->helper('text');
}

	public function index()
	{
	$data['id_karyawan'] = $this->session->userdata('id_karyawan');
$data['password'] = $this->session->userdata('password');
		$this->load->view('apoteker/tambahobat');
	}

public function showObat()
{

$data['listObat'] = $this->m_obat->getAllObat();
$this->load->view('apoteker/obat', $data);
}

public function addObat()
{
$this->load->view('tambahobat');
}
public function addobatDb()
{
$data = array(
'id_obat' => $this->input->post('id_obat'),
'nama' => $this->input->post('nama'),
'jumlah' => $this->input->post('jumlah'),
'harga' => $this->input->post('harga'),
'kategori' => $this->input->post('kategori'),
'perusahaan' => $this->input->post('perusahaan'),

);
$this->m_obat->addObat($data);
redirect('/index.php/apoteker/c_obat');

}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */