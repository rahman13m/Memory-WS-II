<?php
session_start();
class c_memeriksa extends CI_Controller {
function __construct(){
parent::__construct();
$this->load->model("m_memeriksa");
if ($this->session->userdata('id_karyawan')=="") {
			redirect('index.php/login');
}
$this->load->helper('text');
}

public function index()
{
$data['id_karyawan'] = $this->session->userdata('id_karyawan');
$data['password'] = $this->session->userdata('password');
$data['listMemeriksa'] = $this->m_memeriksa->getAllMemeriksa();
$this->load->view('apoteker/memeriksa', $data);
}


public function detailMemeriksa($id_resep)
{
$data['detailmemeriksa'] = $this->m_memeriksa->getMemeriksa($id_resep);
$this->load->view('apoteker/detailMemeriksa', $data);
}
public function detailMemeriksaDb()
{
$data = array(
'nama_poli' => $this->input->post('nama_poli'),
'tanggal' => $this->input->post('tanggal'),
'tindakan' => $this->input->post('tindakan'),
'jenis_penyakit' => $this->input->post('jenis_penyakit'),
'jenis_pengobatan' => $this->input->post('jenis_pengobatan'),
'biaya_tindakan' => $this->input->post('biaya_tindakan'),
'status_pembayaran' => $this->input->post('status_pembayaran'),
'id_karyawan' => $this->input->post('id_karyawan'),
'no_medicalrecord' => $this->input->post('no_medicalrecord'),
'status_diagnosa' => $this->input->post('status_diagnosa'),
'status_pembuatan' => $this->input->post('status_pembuatan'),
'id_resep' => $this->input->post('id_resep'),
'total_harga' => $this->input->post('total_harga')
);
$condition['id_resep'] = $this->input->post('id_resep'); 
$this->m_memeriksa->updateMemeriksa($data, $condition);
redirect('/index.php/apoteker/c_memeriksa');
}


function search_keyword()
    {
        $keyword = $this->input->post('keyword');
        $data['listMemeriksa'] = $this->m_memeriksa->search($keyword);
        $this->load->view('apoteker/memeriksa',$data);
    }

}