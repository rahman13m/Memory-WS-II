<html>
<body border="1">
<br>
<br>


<h4 align="center"><u>SURAT RUJUKAN
</u></h4>
<br>
<br>
<br>
<br>
&nbsp; &nbsp; &nbsp;  &nbsp;
Kepada Yth,<br>
<br>
&nbsp; &nbsp; &nbsp;  &nbsp;
Dokter Gigi Drg. Yuniar dahriani siregar, Sp. PM<br>
<br>
&nbsp; &nbsp; &nbsp;  &nbsp;
Di Rumah Sakit Gigi dan Mulut Prima<br>
<br>
<br>
<br>
<br>
&nbsp; &nbsp; &nbsp;  &nbsp;
Dengan hormat,<br>
<br>
&nbsp; &nbsp; &nbsp;  &nbsp;
Mohon pemeriksaan dan pengobatan lebih lanjut terhadap penderita :
<br>
<br>


<table 521px="" width:="">
 <tbody>
<tr height="20" style="height: 15pt;">
  <td height="20" style="height: 15pt; width: 105pt;" width="140">&nbsp; &nbsp; &nbsp;  &nbsp;Nama Pasien</td>
  <td style="width: 7pt;" width="9">:</td>
  <td style="width: 279pt;" width="372"></td>
 </tr>
<tr height="20" style="height: 15pt;">
  <td height="20" style="height: 15pt;">&nbsp; &nbsp; &nbsp;  &nbsp;Jenis Kelamin</td>
  <td>:</td>
  <td></td>
 </tr>
<tr height="20" style="height: 15pt;">
  <td height="20" style="height: 15pt;">&nbsp; &nbsp; &nbsp;  &nbsp;Umur</td>
  <td>:</td>
  <td></td>
 </tr>
<tr height="20" style="height: 15pt;">
  <td height="20" style="height: 15pt;">&nbsp; &nbsp; &nbsp;  &nbsp;No. Telepon</td>
  <td>:</td>
  <td></td>
 </tr>
<tr height="20" style="height: 15pt;">
  <td height="20" style="height: 15pt;">&nbsp; &nbsp; &nbsp;  &nbsp;Alamat</td>
  <td>:</td>
  <td></td>
 </tr>
</tbody></table>
<br>
<br>
<br>
&nbsp; &nbsp; &nbsp;  &nbsp;
Pada pemeriksaan saya mendapatkan :
<br>
<br>
<ol>
<li>&nbsp; &nbsp; &nbsp;  &nbsp;
Anamnese
<br>
<br>
&nbsp; &nbsp; &nbsp;  &nbsp;
Keluhan &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp;  &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp;: <br><br>
<br>
<br>
&nbsp; &nbsp; &nbsp;  &nbsp;
Diagnosa sementara &nbsp; &nbsp; &nbsp;  &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : <br><br>
<br>
<br>
&nbsp; &nbsp; &nbsp;  &nbsp;
Kasus &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; :
<br>
<br>
<br><br>2. Terapi/Obat yang telah diberikan &nbsp;  : </li>
</ol><br>
<br><br>
<br>

&nbsp; &nbsp; &nbsp;  &nbsp;
Demikian surat rujukan ini kami kirim, kami mohon balasan atas surat rujukan ini. Atas perhatian Bapak/Ibu kami  &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp;  &nbsp;&nbsp; &nbsp; &nbsp;  &nbsp;&nbsp; &nbsp; &nbsp;  &nbsp;ucapkan terima kasih.<br>
<br>
<br>

<p align="right">
Hormat kami&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp; 
<br><br><br><br><br><br><br>
<b><u>Drg. Febry Rahmadani</u></b><br><br>
No. SIP : 7832 64773799  
</p>
</body>
</html>
