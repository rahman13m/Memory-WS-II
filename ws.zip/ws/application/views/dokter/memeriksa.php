<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	

    <title>DIAGNOSA</title>
	
    <!-- css -->
    <link href="http://localhost/ws/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="http://localhost/ws/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<link rel="http://localhost/ws/stylesheet" type="text/css" href="plugins/cubeportfolio/css/cubeportfolio.min.css">
	<link href="http://localhost/ws/css/nivo-lightbox.css" rel="stylesheet" />
	<link href="http://localhost/ws/css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
	<link href="http://localhost/ws/css/owl.carousel.css" rel="stylesheet" media="screen" />
    <link href="http://localhost/ws/css/owl.theme.css" rel="stylesheet" media="screen" />
	<link href="http://localhost/ws/css/animate.css" rel="stylesheet" />
    <link href="http://localhost/ws/css/style.css" rel="stylesheet">

	<!-- boxed bg -->
	<link id="bodybg" href="http://localhost/ws/img/photo/1.jpg" rel="stylesheet" type="text/css" />
	<!-- template skin -->
	<link id="t-colors" href="http://localhost/ws/color/default.css" rel="stylesheet">
	<style type="text/css">
	table{
		border-radius:5px;
	}
	body,td,th {
	font-family: "Open Sans", sans-serif;
}
body {
	background-color: #FFF;
}
h1,h2,h3,h4,h5,h6 {
	font-family: Roboto, sans-serif;
}
    </style>

</head>



<body id="page-top" data-spy="scroll" data-target=".navbar-custom">


<div id="wrapper">
	
  <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="top-area">
			<div class="container">
			  <div class="row">
					<div class="col-sm-6 col-md-6">
					<p class="bold text-left">Halaman Khusus Dokter</p>
					</div>
					<div class="col-sm-6 col-md-6">
					<p class="bold text-right">&nbsp;</p>
				  </div>
				</div>
			</div>
		</div>
        <div class="container navigation">
		
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="<?= base_url() ?>index.php/dokter/c_memeriksa/">
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
			  <ul class="nav navbar-nav">
			   <li><a href="<?= base_url() ?>index.php/dokter/c_obat/">Cari Obat</a></li>
				<li class="active"><a href="<?= base_url() ?>index.php/dokter/c_memeriksa/">Diagnosa</a></li>
                <li ><a href="<?= base_url() ?>index.php/dokter/c_mendapatkan/">Resep</a></li>
                <li><a href="<?= base_url() ?>index.php/login/logout">Logout</a></li>
				
			  </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
	
	<!-- Section: intro -->
    <section class="intro" id="intro" name="intro">
		<div class="intro-content">
					<div class="wow fadeInDown" data-wow-offset="0" data-wow-delay="0.1s">
        <div class="left-menu">
      <div align="center">
        <h3>DIAGNOSA</h3></div> 		  
       <div align="center">
	   <form method="post" action="<?= base_url() ?>index.php/dokter/c_memeriksa/search_keyword/">
        <b>Masukkan No Medical&nbsp;&nbsp;&nbsp;&nbsp; :&nbsp;&nbsp;</b> 
          <input  type="text" name = "keyword" placeholder="Pencarian" size="30" required>
        <input type="submit" value="search">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<span><a href="<?= base_url() ?>index.php/dokter/c_tambahmemeriksa/"><button class="glyphicon glyphicon-plus" type="button" >TambahDiagnosa</button></a></span>
		</form></div>
		<p>&nbsp </p>
		
					<table  border="1" align="center">
				<thead >
					<tr >
						<th class="text-center" width="50" bgcolor="#4ACCD1">No.</th>
						<th class="text-center" width="150" bgcolor="#4ACCD1">Nama Poli</th>
						<th class="text-center" width="150" bgcolor="#4ACCD1">No Medical</th>
                        <th class="text-center" width="150" bgcolor="#4ACCD1">Jenis Penyakit</th>
						<th class="text-center" width="responsive" bgcolor="#4ACCD1">Action</th>
					</tr>
			  </thead>
				<tbody>
					<?php
					
						//Kita akan melakukan looping sesuai dengan data yang dimiliki
						$i=1; //nantinya akan digunakan untuk pengisian Nomor
						foreach ($listMemeriksa->result() as $row) {
						
					?>	
					<tr>
						<td bgcolor="#FFFFFF" align="center"><?php echo $i++ ?></td>
						<td bgcolor="#FFFFFF" align="center"><?= $row->nama_poli?></td> 
						<td bgcolor="#FFFFFF" align="center"><?= $row->no_medicalrecord?></td>
						<td bgcolor="#FFFFFF" align="center"><?= $row->jenis_penyakit?></td>
						<td bgcolor="#FFFFFF" align="center">
							<!-- Akan melakukan update atau delete sesuai dengan id yang diberikan ke controller -->
						  <a href="<?= base_url() ?>index.php/dokter/c_memeriksa/updateMemeriksaDb/<?= $row->id_resep ?>"><input class="input btn-warning" type="submit" value="edit" /></a>
							<a href="<?= base_url() ?>index.php/dokter/c_memeriksa/detailMemeriksa/<?= $row->id_resep ?>"><input type="submit" class="input btn-info" value="lihatDetail" /></a>
						</td>
					</tr>
					<?php
						}
					?>
				</tbody>
	</table>
		
		
		</div>
</div>		
</div>
    </section>

	<footer>
			<div class="row">
					<div align="center" class="wow fadeInLeft" data-wow-delay="0.1s">
			
					<p>&copy;Copyright - Politeknik Negeri Batam 2017</p>
					</div>
		
	  </div>
  </footer>

</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

	<!-- Core JavaScript Files -->
    <script src="http://localhost/ws/js/jquery.min.js"></script>	 
    <script src="http://localhost/ws/js/bootstrap.min.js"></script>
    <script src="http://localhost/ws/js/jquery.easing.min.js"></script>
	<script src="http://localhost/ws/js/wow.min.js"></script>
	<script src="http://localhost/ws/js/jquery.scrollTo.js"></script>
	<script src="http://localhost/ws/js/jquery.appear.js"></script>
	<script src="http://localhost/ws/js/stellar.js"></script>
	<script src="http://localhost/ws/plugins/cubeportfolio/js/jquery.cubeportfolio.min.js"></script>
	<script src="http://localhost/ws/js/owl.carousel.min.js"></script>
	<script src="http://localhost/ws/js/nivo-lightbox.min.js"></script>
    <script src="http://localhost/ws/js/custom.js"></script>
    
</body>

</html>
