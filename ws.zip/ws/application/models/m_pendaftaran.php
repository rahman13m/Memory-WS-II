<?php
class m_pendaftaran extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	
	function getAllPendaftaran()
	{
		$this->db->select("*");
		$this->db->from("pendaftaran");
		
		return $this->db->get();
	}
	
	function getPendaftaran($id)
	{
		$this->db->where('no_medicalrecord', $id); 
		$this->db->select("*");
		$this->db->from("pasien");
		return $this->db->get();
	}
	
	function getdetailPendaftaran($id)
	{
		$this->db->where('no_medicalrecord', $id); 
		$this->db->select("*");
		$this->db->from("pendaftaran");
		return $this->db->get();
	}
	
	function addPendaftaran($data)
	{
		$this->db->insert('pendaftaran', $data);
	}
	
	function updatePendaftaran($data, $condition)
	{
		$this->db->where($condition); 
		$this->db->update('pendaftaran', $data); 
	}

	function deletePendaftaran($id)
	{
		$this->db->where('no_medicalrecord', $id);
		$this->db->delete('pendaftaran');
	}
	
	function search($keyword)
    {
        $this->db->like('no_medicalrecord',$keyword);
        $this->db->from('pendaftaran');
        return $this->db->get();
    }
	
}