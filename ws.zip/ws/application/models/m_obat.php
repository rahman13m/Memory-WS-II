<?php
class m_obat extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	
	function getAllObat()
	{
		$this->db->select("*");
		$this->db->from("obat");
		
		return $this->db->get();
		}

	function getObat($id)
	{
		$this->db->where('id_obat', $id); 
		$this->db->select("*");
		$this->db->from("obat");
		return $this->db->get();
	}
	
	function addObat($data)
	{
		$this->db->insert('obat', $data);
	}
	
	function updateObat($data, $condition)
	{
		$this->db->where($condition); 
		$this->db->update('obat', $data); 
	}

	function deleteObat($id)
	{
		$this->db->where('id_obat', $id);
		$this->db->delete('obat');
	}
	
	function search($keyword)
    {
        $this->db->like('nama',$keyword);
		$this->db->OR_like('id_obat',$keyword);
        $this->db->from('obat');
        return $this->db->get();
    }
} 