<?php
class m_bpjs extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	
	function getAllBpjs()
	{
		$this->db->select("*");
		$this->db->from("bpjs");
		
		return $this->db->get();
	}
	
	function getBpjs($id)
	{
		$this->db->where('no_bpjs', $id); 
		$this->db->select("*");
		$this->db->from("bpjs");
		return $this->db->get();
	}
	
	function addBpjs($data)
	{
		$this->db->insert('bpjs', $data);
	}
	
	function updateBpjs($data, $condition)
	{
		$this->db->where($condition); 
		$this->db->update('bpjs', $data); 
	}

	function deleteBpjs($id)
	{
		$this->db->where('no_bpjs', $id);
		$this->db->delete('bpjs');
	}
	
	function search($keyword)
    {
        $this->db->like('no_bpjs',$keyword);
		$this->db->OR_like('nama',$keyword);
        $this->db->from('bpjs');
        return $this->db->get();
    }
	
}