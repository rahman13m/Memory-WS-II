<?php
class m_pasien extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	
	function getAllPasien()
	{
		$this->db->select("*");
		$this->db->from("pasien");
		
		return $this->db->get();
	}
	
	function getPasien($id)
	{
		$this->db->where('no_medicalrecord', $id); 
		$this->db->select("*");
		$this->db->from("pasien");
		return $this->db->get();
	}
	
	function addPasien($data)
	{
		$this->db->insert('pasien', $data);
	}
	
	function updatePasien($data, $condition)
	{
		$this->db->where($condition); 
		$this->db->update('pasien', $data); 
	}

	function deletePasien($id)
	{
		$this->db->where('no_medicalrecord', $id);
		$this->db->delete('pasien');
	}
	
	function search($keyword)
    {
        $this->db->like('nama',$keyword);
		$this->db->OR_like('no_medicalrecord',$keyword);
        $this->db->from('pasien');
        return $this->db->get();
    }
}