<?php
class m_memeriksa extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}

	
	function getAllMemeriksa()
	{
		$this->db->select("*");
		$this->db->from("memeriksa");
		
		return $this->db->get();
		}

	function getMemeriksa($id)
	{
		$this->db->where('id_resep', $id); 
		$this->db->select("*");
		$this->db->from("memeriksa");
		return $this->db->get();
	}
	
	function addMemeriksaDb($data)
	{
		$this->db->insert('memeriksa', $data);
	}
	
	function updateMemeriksa($data, $condition)
	{
		$this->db->where($condition); 
		$this->db->update('memeriksa', $data); 
	}
	
	function search($keyword)
    {
        $this->db->like('no_medicalrecord',$keyword);
		$this->db->OR_like('id_karyawan',$keyword);
        $this->db->from('memeriksa');
        return $this->db->get();
    }
} 